class Account < ActiveRecord::Base
  belongs_to :order
  has_one :contact_info
  has_one :user
  
  accepts_nested_attributes_for :contact_info, :user
end
