class DummyRedirectController < ApplicationController
  def one
    redirect_to :controller => "dummy_redirect", :action => "two"
  end

  def two
  end

end
