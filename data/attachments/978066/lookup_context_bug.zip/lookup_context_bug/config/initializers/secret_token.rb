# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
LookupContextBug::Application.config.secret_token = 'f1771a29b6f86a8305d6aee01daa7a1d7480e9e1a8abf3224d778d5f7cfe68d21fb996675a9fddfb3aada0e796502a6388daea4f24d353558b4c502cf4844e72'
