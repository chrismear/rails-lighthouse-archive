class CreateHavers < ActiveRecord::Migration
  def self.up
    create_table :havers do |t|
      
      t.timestamps
    end
  end

  def self.down
    drop_table :havers
  end
end
