# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '540ae57e20f1fca4091084e7cb1a5b098a84f33bb22102cb27dbf69600c9e806ef7f4f92ae32f98fa2ecc97279fc2f78903680b4356a1a9b50e046e95e69ebc2'
