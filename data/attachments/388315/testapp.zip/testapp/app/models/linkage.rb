require 'pp'

class Linkage < ActiveRecord::Base

  belongs_to :foo
  belongs_to :thing, :polymorphic => true

end