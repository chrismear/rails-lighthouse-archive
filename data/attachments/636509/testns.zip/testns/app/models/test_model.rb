class TestModel < ActiveRecord::Base
  
  belongs_to :parent_model
  
  named_scope :high_priority, :conditions=>"priority > 5"
  named_scope :low_priority, :conditions=>"priority <= 5"
  
  named_scope :ordered, :order=>"name asc"
  
  
end
