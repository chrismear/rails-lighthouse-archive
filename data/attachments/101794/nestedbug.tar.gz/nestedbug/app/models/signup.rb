class Signup < ActiveRecord::Base
end
