# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '3fd8938c6cb723bd069d63dc8fb1cb9c6daad008e418b49ff8cd1d8501f2d380b5a8b7ad365327337d2420b8faa4df414102031ab14710428ea8005fde6ce122'
