class ObjectCsController < ApplicationController
  # GET /object_cs
  # GET /object_cs.xml
  def index
    @object_cs = ObjectC.all

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @object_cs }
    end
  end

  # GET /object_cs/1
  # GET /object_cs/1.xml
  def show
    @object_c = ObjectC.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @object_c }
    end
  end

  # GET /object_cs/new
  # GET /object_cs/new.xml
  def new
    @object_c = ObjectC.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @object_c }
    end
  end

  # GET /object_cs/1/edit
  def edit
    @object_c = ObjectC.find(params[:id])
  end

  # POST /object_cs
  # POST /object_cs.xml
  def create
    @object_c = ObjectC.new(params[:object_c])

    respond_to do |format|
      if @object_c.save
        flash[:notice] = 'ObjectC was successfully created.'
        format.html { redirect_to(@object_c) }
        format.xml  { render :xml => @object_c, :status => :created, :location => @object_c }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @object_c.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /object_cs/1
  # PUT /object_cs/1.xml
  def update
    @object_c = ObjectC.find(params[:id])

    respond_to do |format|
      if @object_c.update_attributes(params[:object_c])
        flash[:notice] = 'ObjectC was successfully updated.'
        format.html { redirect_to(@object_c) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @object_c.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /object_cs/1
  # DELETE /object_cs/1.xml
  def destroy
    @object_c = ObjectC.find(params[:id])
    @object_c.destroy

    respond_to do |format|
      format.html { redirect_to(object_cs_url) }
      format.xml  { head :ok }
    end
  end
end
