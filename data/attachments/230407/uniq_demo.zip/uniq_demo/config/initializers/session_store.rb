# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_uniq_demo_session',
  :secret      => '3cd9b05bf1b2bff650e3e60127690bba370f1b1a2b534add4f818387741ba6939265afa752ea3c1ad60c61c0e959de22e48e9f4ae97530bb8c8213596eb6c2f4'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
