# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = 'd2ada60aef647070a5f8bb85c04e08a34bf320f0d62f10ee550b4462e1c486a49136f9e574ca7576fa5834efe26ab6baaf7653078492fc8435c46119a8114ab2'
