class SubitemsController < ApplicationController
  def index
    @subitems = Subitem.all
  end
end
