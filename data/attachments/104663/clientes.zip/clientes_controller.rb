class ClientesController < ApplicationController
  # GET /clientes
  # GET /clientes.xml
  def index
    nome_telefone = ''
    nome_telefone = params[:nome_telefone] unless params[:nome_telefone].blank?
    @clientes = Cliente.find(:all, :conditions => ["lower(nome) like ?", '%' + nome_telefone + '%'])
    TelefoneDoCliente.all(:conditions => ["telefone like ?", '%' + nome_telefone + '%']).each do |telefone_do_cliente|
      @clientes << telefone_do_cliente.cliente unless @clientes.include?(telefone_do_cliente.cliente)
    end
    @clientes.sort! { |c1, c2| c1.nome.downcase <=> c2.nome.downcase }

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @clientes }
      #format.xls { send_data @clientes.to_xls } #TODO tirar isso daqui
    end
  end

  # GET /clientes/1
  # GET /clientes/1.xml
  def show
    @cliente = Cliente.find(params[:id])
    @data_comemorativas = grava_lista_datas(DataComemorativa.gera_lista(@cliente))
    @endereco_do_clientes = grava_lista_enderecos(EnderecoDoCliente.gera_lista(@cliente))
    @telefone_do_clientes = grava_lista_telefones(TelefoneDoCliente.gera_lista(@cliente))

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @cliente }
    end
  end

  # GET /clientes/new
  # GET /clientes/new.xml
  def new
    @cliente = Cliente.new
    @data_comemorativas = grava_lista_datas
    @endereco_do_clientes = grava_lista_enderecos
    @telefone_do_clientes = grava_lista_telefones
    @taxa_de_entregas = TaxaDeEntrega.find(:all, :order => "lower(nome) ASC")
    @tipo_de_telefones = TipoDeTelefone.find(:all, :order => "lower(nome) ASC")
    grava_para_venda(! params[:para_venda].blank?)
    tabela_de_preco = TabelaDePreco.find(:first)
    @tabela_de_precos = (TabelaDePreco.find(:all, :conditions => ["id != ?", tabela_de_preco.id], :order => "lower(nome) ASC").reverse << tabela_de_preco).reverse

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @cliente }
    end
  end

  # GET /clientes/1/edit
  def edit
    @cliente = Cliente.find(params[:id])
    @data_comemorativas = grava_lista_datas(DataComemorativa.gera_lista(@cliente))
    @endereco_do_clientes = grava_lista_enderecos(EnderecoDoCliente.gera_lista(@cliente))
    @telefone_do_clientes = grava_lista_telefones(TelefoneDoCliente.gera_lista(@cliente))
    @taxa_de_entregas = TaxaDeEntrega.find(:all, :order => "lower(nome) ASC")
    @tipo_de_telefones = TipoDeTelefone.find(:all, :order => "lower(nome) ASC")
    tabela_de_preco = TabelaDePreco.find(:first)
    @tabela_de_precos = (TabelaDePreco.find(:all, :conditions => ["id != ?", tabela_de_preco.id], :order => "lower(nome) ASC").reverse << tabela_de_preco).reverse
  end

  # POST /clientes
  # POST /clientes.xml
  def create
    @cliente = Cliente.new(params[:cliente])
    @data_comemorativas = le_lista_datas
    @endereco_do_clientes = le_lista_enderecos
    @telefone_do_clientes = le_lista_telefones
    @taxa_de_entregas = TaxaDeEntrega.find(:all, :order => "lower(nome) ASC")
    @tipo_de_telefones = TipoDeTelefone.find(:all, :order => "lower(nome) ASC")
    tabela_de_preco = TabelaDePreco.find(:first)
    @tabela_de_precos = (TabelaDePreco.find(:all, :conditions => ["id != ?", tabela_de_preco.id], :order => "lower(nome) ASC").reverse << tabela_de_preco).reverse

    # envia para o objeto a quantidade de telefones cadastrados para o cliente
    @cliente.quantidade_de_telefones = @telefone_do_clientes.lista.length

    respond_to do |format|
      if @cliente.save
        DataComemorativa.salvar_lista(@cliente.id, @data_comemorativas.lista)
        EnderecoDoCliente.salvar_lista(@cliente.id, @endereco_do_clientes.lista)
        TelefoneDoCliente.salvar_lista(@cliente.id, @telefone_do_clientes.lista)

        # se o cadastro do cliente está sendo feito para uma venda
        if le_para_venda
          flash[:notice] = 'Nova venda para o cliente ' + @cliente.nome + ', recém cadastrado.'
          redirect_to :controller => "vendas", :action => "new", :cliente => { :nome => @cliente.nome }
          return
        else
          flash[:notice] = 'Cliente cadastrado com sucesso.'
          format.html { redirect_to(@cliente) }
          format.xml  { render :xml => @cliente, :status => :created, :location => @cliente }
        end
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @cliente.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /clientes/1
  # PUT /clientes/1.xml
  def update
    @cliente = Cliente.find(params[:id])
    @data_comemorativas = le_lista_datas
    @endereco_do_clientes = le_lista_enderecos
    @telefone_do_clientes = le_lista_telefones
    @taxa_de_entregas = TaxaDeEntrega.find(:all, :order => "lower(nome) ASC")
    @tipo_de_telefones = TipoDeTelefone.find(:all, :order => "lower(nome) ASC")
    tabela_de_preco = TabelaDePreco.find(:first)
    @tabela_de_precos = (TabelaDePreco.find(:all, :conditions => ["id != ?", tabela_de_preco.id], :order => "lower(nome) ASC").reverse << tabela_de_preco).reverse

    # envia para o objeto a quantidade de telefones cadastrados para o cliente
    @cliente.quantidade_de_telefones = @telefone_do_clientes.lista.length

    respond_to do |format|
      if @cliente.update_attributes(params[:cliente])
        DataComemorativa.salvar_lista(@cliente.id, @data_comemorativas.lista, @data_comemorativas.removidos)
        EnderecoDoCliente.salvar_lista(@cliente.id, @endereco_do_clientes.lista, @endereco_do_clientes.removidos)
        TelefoneDoCliente.salvar_lista(@cliente.id, @telefone_do_clientes.lista, @telefone_do_clientes.removidos)
        flash[:notice] = 'Cliente atualizado com sucesso.'
        format.html { redirect_to(@cliente) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @cliente.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /clientes/1
  # DELETE /clientes/1.xml
  def destroy
    @cliente = Cliente.find(params[:id])
    unless @cliente.possui_associacao?(['data_comemorativa_ids', 'endereco_do_cliente_ids', 'telefone_do_cliente_ids'])
      DataComemorativa.apagar_lista(@cliente.id)
      EnderecoDoCliente.apagar_lista(@cliente.id)
      TelefoneDoCliente.apagar_lista(@cliente.id)
      @cliente.destroy
    else
      @cliente.inativo!
      flash[:notice] = 'O cliente não pôde ser excluído, pois possui histórico de compra. ' + @cliente.nome + ' foi desativado.'
    end

    respond_to do |format|
      format.html { redirect_to(clientes_url) }
      format.xml  { head :ok }
    end
  end

  def adiciona_data
    @data_comemorativas = le_lista_datas

    # 0 para true e 1 para false
    if params[:data][:uma_vez].to_i == 0
      uma_vez = true
    else
      uma_vez = false
    end
    # 1 para true e 0 para false
    if params[:data][:enviar_felicitacoes].to_i == 1
      enviar_felicitacoes = true
    else
      enviar_felicitacoes = false
    end

    @data_comemorativas.adiciona_data(Date.parse(params[:data][:data]), params[:data][:descricao], uma_vez, enviar_felicitacoes)

    respond_to { |format| format.js }
  end

  def remove_data
    @data_comemorativas = le_lista_datas

    @data_comemorativas.remove_data(Date.parse(params[:data]), params[:descricao])

    respond_to { |format| format.js }
  end

  def adiciona_endereco
    @endereco_do_clientes = le_lista_enderecos

    cidade = params[:endereco][:cidade].gsub(/\//, '')
	cidade += '/' + params[:endereco][:uf].gsub(/\//, '')
    cidade.gsub!(/^\//, '')
    cidade.gsub!(/\/$/, '')
    @endereco_do_clientes.adiciona_endereco(params[:endereco][:endereco], params[:endereco][:bairro], cidade, params[:endereco][:cep], TaxaDeEntrega.find(params[:endereco][:taxa_de_entrega]))

    respond_to { |format| format.js }
  end

  def remove_endereco
    @endereco_do_clientes = le_lista_enderecos

    @endereco_do_clientes.remove_endereco(params[:endereco])

    respond_to { |format| format.js }
  end

  def adiciona_telefone
    @telefone_do_clientes = le_lista_telefones
    telefone = params[:telefone][:telefone].gsub(/[^0-9]/, '')
    telefone += '#' + params[:telefone][:ramal].gsub(/[^0-9]/, '') unless params[:telefone][:ramal].blank?
    @telefone_do_clientes.adiciona_telefone(telefone, TipoDeTelefone.find(params[:telefone][:tipo_de_telefone]))

    respond_to { |format| format.js }
  end

  def remove_telefone
    @telefone_do_clientes = le_lista_telefones

    @telefone_do_clientes.remove_telefone(params[:telefone])

    respond_to { |format| format.js }
  end

  private
  def le_lista_datas
    session[:lista_datas] ||= ListaDeDatas.new
  end

  def grava_lista_datas(lista = ListaDeDatas.new)
    session[:lista_datas] = lista
    le_lista_datas
  end

  def le_lista_enderecos
    session[:lista_enderecos] ||= ListaDeEnderecos.new
  end

  def grava_lista_enderecos(lista = ListaDeEnderecos.new)
    session[:lista_enderecos] = lista
    le_lista_enderecos
  end

  def le_lista_telefones
    session[:lista_telefones] ||= ListaDeTelefones.new
  end

  def grava_lista_telefones(lista = ListaDeTelefones.new)
    session[:lista_telefones] = lista
    le_lista_telefones
  end

  def grava_para_venda(para_venda = false)
    session[:para_venda] = para_venda
    le_para_venda
  end

  def le_para_venda
    session[:para_venda] ||= false
  end
end
