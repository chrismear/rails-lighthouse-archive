# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
App::Application.config.secret_token = '80943042609d6ea2e064fc150febc95951cd3ef0472d8bec9ecf55f944d5a82281316b0cea7840d288d2d1071a68d5e786d9acea7e6c1ad7b867f7fa72891bb3'
