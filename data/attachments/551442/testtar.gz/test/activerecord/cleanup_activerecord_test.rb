require 'rubygems'
require 'bundler'
require 'ruby-debug'
Bundler.setup

require 'rails/all'

$:.unshift << File.dirname(__FILE__)

module MyApp
  class Application < Rails::Application
    def run_initializers(*args)
      return if instance_variable_defined?(:@ran)
      initializers.each do |initializer|
        if initializer.name == "active_record.initialize_database"
          ActiveRecord::Base.establish_connection(
            :adapter => 'sqlite3',
            :database => 'awesome.db')
        else
          initializer.run(*args)
        end
      end
      @ran = true
    end
  end
end

Rails::Application.configure do
  config.cache_classes = false
  config.secret_token = 'a'*35
  config.session_store = :cookie_store, {:key => "b"*35 }
  config.key = 'c'*35
end

Rails.application.config.session_store :cookie_store, { :key => 'e'*35 }

Rails::Application.initialize!


class MyMigration < ActiveRecord::Migration
  def self.up
    create_table :as, :force => true do |t|
      t.integer :c_id
    end
    create_table :bs, :force => true  do |b|
      b.integer :a_id
      b.integer :c_id
      b.timestamps
    end
    create_table :cs, :force => true  do |b|
    end
  end
end

ActiveSupport::Dependencies.load_paths.unshift(File.dirname(__FILE__))

require 'test/unit'

class Sample
  def self.call(arg)
    a = A.first
    b = a.bs[0]
#   This is the suggested debuger point.  You can print things like
#   B.__id__, and b.class.instance_methods(false) which shows that
#   the B gotten from the above, in the second iteration, is somehow
#   the cached one from the first run.
#
#    debugger
    c = b.c
  end
end

MyMigration.up

class CleanupActiveRecordTest < Test::Unit::TestCase
  def setup
    c = C.create
    c.as.create
    b = B.new
    b.a = c.as[0]
    b.c = c
    b.save
  end

  def test_classes_found
    
    5.times do |i|
      ActionDispatch::Callbacks.new(Sample, true).call(nil) 
    end
  end
end
