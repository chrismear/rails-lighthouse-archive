# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_testns_session',
  :secret      => '594bf750a1c083b6c46efa33377873697e7613783ceb01074acf7a622d82d2fd70c282a8c9fa964c3567d6acafcedc740d1a3e025f107354fe2ede00fd93de52'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
