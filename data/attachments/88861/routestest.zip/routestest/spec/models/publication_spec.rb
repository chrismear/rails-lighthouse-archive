require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe Publication do

  fixtures :products, :publications

  before(:each) do
    configure_shop
    @valid_attributes = {
      :thumb => get_test_file,
      :full => get_test_file,
      :name => 'Name 1',
      :description => 'a publication',
      :product => products(:dress_1)
    }
  end

  it "should create a new instance given valid attributes" do
    publication = Publication.create!(@valid_attributes)
    
    File.exists?(publication.thumb.path).should be_true
    File.exists?(publication.full.path).should be_true
  end

  it "should update existing product_collections with valid attributes" do
    publications(:magazine).update_attributes!(@valid_attributes)
  end

end