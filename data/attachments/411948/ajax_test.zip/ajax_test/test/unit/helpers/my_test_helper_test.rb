require 'test_helper'

class MyTestHelperTest < ActionView::TestCase
end
