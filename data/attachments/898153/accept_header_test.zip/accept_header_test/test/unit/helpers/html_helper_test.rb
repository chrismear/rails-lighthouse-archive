require 'test_helper'

class HtmlHelperTest < ActionView::TestCase
end
