ActionController::Routing::Routes.draw do |map|
  
  map.with_options :controller => "third_party_extension" do |custom|
    %w(template_with_no_action template_with_empty_action template_with_render_template template_with_render_template_with_extension).each do |action|
      custom.send(action, "/#{action}", :action => action)
    end
  end
  
end
