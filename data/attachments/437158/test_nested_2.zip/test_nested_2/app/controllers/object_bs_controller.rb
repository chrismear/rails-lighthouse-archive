class ObjectBsController < ApplicationController
  # GET /object_bs
  # GET /object_bs.xml
  def index
    @object_bs = ObjectB.all

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @object_bs }
    end
  end

  # GET /object_bs/1
  # GET /object_bs/1.xml
  def show
    @object_b = ObjectB.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @object_b }
    end
  end

  # GET /object_bs/new
  # GET /object_bs/new.xml
  def new
    @object_b = ObjectB.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @object_b }
    end
  end

  # GET /object_bs/1/edit
  def edit
    @object_b = ObjectB.find(params[:id])
  end

  # POST /object_bs
  # POST /object_bs.xml
  def create
    @object_b = ObjectB.new(params[:object_b])

    respond_to do |format|
      if @object_b.save
        flash[:notice] = 'ObjectB was successfully created.'
        format.html { redirect_to(@object_b) }
        format.xml  { render :xml => @object_b, :status => :created, :location => @object_b }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @object_b.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /object_bs/1
  # PUT /object_bs/1.xml
  def update
    @object_b = ObjectB.find(params[:id])

    respond_to do |format|
      if @object_b.update_attributes(params[:object_b])
        flash[:notice] = 'ObjectB was successfully updated.'
        format.html { redirect_to(@object_b) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @object_b.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /object_bs/1
  # DELETE /object_bs/1.xml
  def destroy
    @object_b = ObjectB.find(params[:id])
    @object_b.destroy

    respond_to do |format|
      format.html { redirect_to(object_bs_url) }
      format.xml  { head :ok }
    end
  end
end
