class Mail < ActionMailer::Base
  
  def daily_report
    recipients      "me@example.com"
    subject         "Daily Report"
    from            "me@example.com"
    content_type    "multipart/alternative"
    
    part :content_type => "text/plain", 
         :body => render_message("daily_report", :date => Time.now, :recipient => "Bob")

    attachment :content_type => "text/csv", :filename => "hello", :body => "my,cool,csv"
    
  end

end
