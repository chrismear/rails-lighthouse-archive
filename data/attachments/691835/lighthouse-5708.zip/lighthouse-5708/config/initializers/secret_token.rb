# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Lighthouse5708::Application.config.secret_token = 'cef80636bde79e98dee4c3d354a70be14f8835f4599372f92a0418024b2a21b654ac3693b31617459ffe0a246bb208f4f91057ccbbeddb4ab8a6417a23407172'
