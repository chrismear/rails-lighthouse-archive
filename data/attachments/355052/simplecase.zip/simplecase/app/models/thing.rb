class Thing < ActiveRecord::Base
  belongs_to :widget
  belongs_to :frob
end
