require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe OrdersController do

  integrate_views

  fixtures :orders, :order_items, :customers, :customer_addresses

  it "should show index" do
    login
    session[:order_id] = orders(:cart_1).id
    
    get 'index', :locale => 'nl'
    
    assigns[:order].should_not be_nil
    assigns[:order].customer.should == customers(:customer_one)
    
    response.should be_success
    response.should render_template('orders/index')
  end

  it "should show index without logged in user" do
    get 'index', :locale => 'nl'
    
    assigns[:order].should be_nil
    
    response.should redirect_to(new_customer_path(:redirect_to_cart => true))
  end

  it "should show new" do
    login
    session[:order_id] = orders(:checkout_1).id
    
    get 'new', :locale => 'nl'
    
    assigns[:order].should_not be_nil
    
    response.should be_success
    response.should render_template('orders/new')
  end

  it "should show new without a logged in user" do
    get 'new', :locale => 'nl'
    
    assigns[:order].should be_nil
    
    response.should redirect_to(welcome_new_order_path)
  end

  it "should show welcome with a logged in user" do
    login
    session[:order_id] = orders(:cart_1).id
    
    get 'welcome', :locale => 'nl'
    
    assigns[:order].should_not be_nil
    assigns[:order].customer.should == customers(:customer_one)
    
    response.should be_success
    response.should render_template('orders/welcome')
  end

  it "should show welcome without a logged in user" do
    get 'welcome', :locale => 'nl'
    
    assigns[:order].should be_nil
    
    response.should redirect_to(new_customer_path(:redirect_to_cart => true))
  end

  it "should finish an order with data from ogone and an accepted payment" do
    post 'finish', :locale => 'nl', :orderID => "#{orders(:checkout_1).id}", :amount => '20000', :currency => 'EUR', :PM => 'IDEAL', :ACCEPTENCE => '000000', :STATUS => '9', 
          :CARDNO => 'xxxxxxxxxxxx1111', :PAYID => '32100123', :NC_ERROR => '0', :BRAND => 'VISA', :SHASIGN => '62B08490EB267D557528F53FE259CCC103A6A07D'
    
    assigns[:merchant_shasign].should == '62B08490EB267D557528F53FE259CCC103A6A07D'
    assigns[:order].state.should == :finished
    assigns[:order].ogone_status.should == '9'
    
    response.should be_success
    response.should render_template('orders/finish')
  end

  it "should not finish an order with data from ogone and a not accepted payment" do
    post 'finish', :locale => 'nl', :orderID => "#{orders(:checkout_1).id}", :amount => '20000', :currency => 'EUR', :PM => 'IDEAL', :ACCEPTENCE => '1234', :STATUS => '1', 
          :CARDNO => 'xxxxxxxxxxxx1111', :PAYID => '32100123', :NC_ERROR => '0', :BRAND => 'VISA', :SHASIGN => '19513C49C6BAD1A89A71DBB2D9F4DB41F5D9A8FA'
    
    assigns[:merchant_shasign].should == '19513C49C6BAD1A89A71DBB2D9F4DB41F5D9A8FA'
    assigns[:order].state.should == :checkout
    assigns[:order].ogone_status.should == '1'
    
    response.should be_success
    response.should render_template('orders/finish')
  end

  it "should not finish an order with data from ogone and an incorrect data string" do
    post 'finish', :locale => 'nl', :orderID => "#{orders(:checkout_1).id}", :amount => '10000', :currency => 'EUR', :PM => 'IDEAL', :ACCEPTENCE => '1234', :STATUS => '9', 
          :CARDNO => 'xxxxxxxxxxxx1111', :PAYID => '32100123', :NC_ERROR => '0', :BRAND => 'VISA', :SHASIGN => '5E54C91A8A6255B806188AE62CA04E18BDD065E9'
    
    assigns[:merchant_shasign].should == 'C029BA6F1CEAEAF1927B5F2461EE5D685D479E87'
    assigns[:merchant_shasign].should_not == assigns[:payment_shasign]
    assigns[:order].state.should == :checkout
    
    response.should be_success
    response.should render_template('orders/finish')
  end

end