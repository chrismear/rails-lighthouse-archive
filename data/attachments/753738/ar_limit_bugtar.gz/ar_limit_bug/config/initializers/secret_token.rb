# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ArLimitBug::Application.config.secret_token = 'a0e5a9e223410a3611dd5d7e584bc175c1f26ee38e957ba5f97ef8b3ca29642ef084dd1dac5b5c294e03394dabbeada3a5d92d46fb88df1cacfff6d0000a7df7'
