class CreateObjectAs < ActiveRecord::Migration
  def self.up
    create_table :object_as do |t|
      t.string :name
      t.integer :object_d_id

      t.timestamps
    end
  end

  def self.down
    drop_table :object_as
  end
end
