require 'test_helper'

class FooHelperTest < ActionView::TestCase
end
