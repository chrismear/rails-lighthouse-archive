require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe FabricSample do
  
  fixtures :fabric_samples, :customer_addresses, :products, :product_variations

  before(:each) do
    @valid_attributes = {
      :first_name => 'customer',
      :last_name => 'one',
      :email => 'customer@customer.com',
      :phone => '123-4567890',
      :customer_address => customer_addresses(:fabric_sample_address),
      :product_variation => product_variations(:dress_1_red)
    }
  end

  it "should create a new instance given valid attributes" do
    FabricSample.create!(@valid_attributes)
  end

  it "should not create anything with invalid attributes" do
    FabricSample.create(@valid_attributes.merge!({:first_name => ''})).should have(1).error_on(:first_name)
    FabricSample.create(@valid_attributes.merge!({:last_name => nil})).should have(1).error_on(:last_name)
    FabricSample.create(@valid_attributes.merge!({:product_variation => nil})).should have(1).error_on(:product_variation)
  end

  it "should have valid fixtures" do
    fabric_samples(:sample_one).should be_valid
    fabric_samples(:sample_without_address).should be_valid
  end

  it "create a customer address" do
    fabric_sample = fabric_samples(:sample_without_address)
    fabric_sample.create_customer_address({:address_one => 'straat 34', :zip => '1234FG', :country => 'NL', :city => 'Amsterdam'})
    fabric_sample.customer_address.should_not be_nil
  end

end