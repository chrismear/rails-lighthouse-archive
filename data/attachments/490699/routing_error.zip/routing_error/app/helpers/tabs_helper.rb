module TabsHelper
end
