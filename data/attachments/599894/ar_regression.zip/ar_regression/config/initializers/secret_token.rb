# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = 'ced5e991707b6163dd276024e7ced9b68d24b36af38726eda2d360a4a79a9a25adcc44340f3536802072c223f52a7739c5ef33c0ec37cdb0917c35daa5af5ec4'
