require 'test_helper'

class TogglerHelperTest < ActionView::TestCase
end
