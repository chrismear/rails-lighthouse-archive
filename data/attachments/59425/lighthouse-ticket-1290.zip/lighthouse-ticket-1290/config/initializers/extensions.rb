MONKEY_ONE = Monkey.first
