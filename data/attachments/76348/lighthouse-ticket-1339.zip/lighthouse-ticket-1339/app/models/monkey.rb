# adding the following require will trigger the reload error
# upon second request. Commenting it out will leave everything 
# working fine after server restart
require 'user_role'

class Monkey < ActiveRecord::Base
end
