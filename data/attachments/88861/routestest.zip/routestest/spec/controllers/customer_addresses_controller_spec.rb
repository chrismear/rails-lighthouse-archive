require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe CustomerAddressesController do

  integrate_views

  fixtures :customers, :customer_addresses, :orders

  before(:each) do
    login
    @valid_attributes = {
      :customer => customers(:customer_one),
      :country => 'NL',
      :city => 'Amsterdam',
      :address_one => 'Vijzelstraat 16b',
      :zip => '1234 XL'
    }
  end

  it "should get index" do
    get 'index', :locale => 'nl'
    
    assigns[:customer_addresses].should_not be_nil
    
    response.should be_success
    response.should render_template('customer_addresses/index')
  end

  it "should get billing" do
    get 'billing', :locale => 'nl'
    
    assigns[:billing_address].should == customer_addresses(:customer_one_billing)
    
    response.should be_success
    response.should render_template('customer_addresses/billing')
  end

  it "should create a new customer_address with valid attributes" do
    post 'create', :locale => 'nl', :customer_address => @valid_attributes
    
    assigns[:customer_address].should be_valid
    assigns[:customer_address].customer.should == customers(:customer_one)
    
    response.should redirect_to(customer_addresses_path)
  end

  it "should not create a new customer_address with invalid attributes" do
    post 'create', :locale => 'nl', :customer_address => @valid_attributes.merge(:country => '')
    
    assigns[:customer_address].should_not be_valid
    
    response.should redirect_to(customer_addresses_path)
  end

  it "should update a customer_address with valid attributes" do
    post 'update', :locale => 'nl', :customer_address => @valid_attributes, :id => customer_addresses(:customer_one_billing)
    
    assigns[:customer_address].should be_valid
    
    response.should redirect_to(customer_addresses_path)
  end

  it "should not update a customer_address with invalid attributes" do
    post 'update', :locale => 'nl', :customer_address => @valid_attributes.merge(:country => ''), :id => customer_addresses(:customer_one_billing)
    
    assigns[:customer_address].should_not be_valid
    
    response.should redirect_to(customer_addresses_path)
  end

  it "should add the shipping address to an order" do
    session[:order_id] = orders(:cart_1).id
    post 'add_shipping_to_order', :locale => 'nl', :id => customer_addresses(:customer_one_billing)
    
    assigns[:order].shipping_address.should == customer_addresses(:customer_one_billing)
    
    response.should be_success
    response.should render_template('customer_addresses/add_shipping_to_order')
  end

end