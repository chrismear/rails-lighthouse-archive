#This is just a stub file so Rails doesn't complain about me not being in the helpers folder
module RubyamfHelper
end