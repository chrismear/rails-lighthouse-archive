class Invoice < ActiveRecord::Base
  has_many :line_items, :primary_key => :invoice_alternate_key, :foreign_key => :invoice_foreign_key
end
