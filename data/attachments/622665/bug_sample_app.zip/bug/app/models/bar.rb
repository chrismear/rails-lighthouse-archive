class Bar < ActiveRecord::Base
  default_scope select('id')
  has_many :bazs
end
