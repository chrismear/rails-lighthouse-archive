class Something

	attr_accessor :a, :b, :c
	
	def initialize
		@a = 1
		@b = 2
		@c = 3
	end

end
