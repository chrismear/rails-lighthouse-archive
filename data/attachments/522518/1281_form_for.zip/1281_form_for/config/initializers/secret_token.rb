# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '6840e9bc7218c7e9bbd49ef0f19567a8e2561f4edf03b42ffa57f679e7437181888b009cc0a74aea558d38af89bbc8a134b049f03b77a254b7f0eb1522558689'
