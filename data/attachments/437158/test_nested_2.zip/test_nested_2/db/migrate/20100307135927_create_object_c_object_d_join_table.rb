class CreateObjectCObjectDJoinTable < ActiveRecord::Migration
  def self.up
    create_table :object_cs_object_ds, :id => false do |t| 
  	t.integer :object_c_id, :null => false 
  	t.integer :object_d_id, :null => false
    end

    add_index :object_cs_object_ds, [:object_c_id, :object_d_id], :unique => true 
  end

  def self.down
    drop_table :object_cs_object_ds
  end
end
