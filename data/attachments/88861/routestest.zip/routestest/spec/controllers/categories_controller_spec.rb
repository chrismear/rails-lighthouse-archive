require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe CategoriesController do

  integrate_views

  fixtures :pages, :categories, :products

  it "should show index with the nl locale" do
    get 'index', :locale => 'nl'
    
    I18n.locale.should == 'nl'
    assigns[:page].should == pages(:home)
    
    response.should be_success
    response.should render_template('categories/index')
  end

  it "should show index with the en locale" do
    get 'index', :locale => 'en'
    
    I18n.locale.should == 'en'
    assigns[:page].should == pages(:home)
    
    response.should be_success
    response.should render_template('categories/index')
  end

  it "should show without a homepage" do
    Page.delete_all
    
    get 'index', :locale => 'nl'
    
    assigns[:page].should be_nil
    
    response.should be_success
    response.should render_template('categories/index')
  end

end