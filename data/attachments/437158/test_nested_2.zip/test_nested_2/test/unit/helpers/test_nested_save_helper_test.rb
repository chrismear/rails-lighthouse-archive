require 'test_helper'

class TestNestedSaveHelperTest < ActionView::TestCase
end
