require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe CustomersController do

  integrate_views

  fixtures :customers

  before do
    @valid_attributes = {:email => 'another_customer@somewhere.com',
                          :new_password => 'new_password',
                          :new_password_confirmation => 'new_password',
                          :first_name => 'FirstName',
                          :last_name => 'LastName',
                          :agreement => true,
                          # not mandatory:
                          :gender => 1,
                          :birthday => '1990-01-01',
                          :phone => '123-123-123',
                          :mobile_phone => '321-321-321'}
  end

  it "should get new" do
    get 'new', :locale => 'nl'
    
    assigns[:customer].should_not be_nil
    
    response.should be_success
    response.should render_template('customers/new')
  end

  it "should create a new customer with valid attributes" do
    post 'create', :locale => 'nl', :customer => @valid_attributes
    
    assigns[:customer].should be_valid
    assigns[:customer].password.should == Customer.encrypt_password(@valid_attributes[:new_password])
    session[:current_customer_id].should == assigns[:customer].id
    
    response.should redirect_to(edit_customer_path)
  end

  it "should create a new customer with valid attributes and redirect to cart" do
    post 'create', :locale => 'nl', :customer => @valid_attributes, :redirect_to_cart => true
    
    assigns[:customer].should be_valid
    assigns[:customer].password.should == Customer.encrypt_password(@valid_attributes[:new_password])
    session[:current_customer_id].should == assigns[:customer].id
    
    response.should redirect_to(billing_customer_addresses_path)
  end

  it "should not create a new customer with invalid attributes" do
    post 'create', :locale => 'nl', :customer => (@valid_attributes.merge(:email => ''))
    
    assigns[:customer].should_not be_valid
    
    response.should be_success
    response.should render_template('customers/new')
  end

  it "should not update anything unless the customer is logged in" do
    post 'update', :locale => 'nl', :customer => @valid_attributes
    
    assigns[:customer].should be_nil
    
    response.should be_success
    response.should render_template('shared/login_required')
  end

  describe CustomersController, "logged in" do

    integrate_views

    fixtures :customers

    before do
      login
      @valid_attributes = {:email => 'another_customer@somewhere.com',
                            :new_password => 'new_password',
                            :new_password_confirmation => 'new_password',
                            :first_name => 'FirstName',
                            :last_name => 'LastName',
                            :agreement => true}
    end

    it "should get edit" do
      get 'edit', :locale => 'nl'
    
      assigns[:customer].should == customers(:customer_one)
    
      response.should be_success
      response.should render_template('customers/edit')
    end

    it "should update a customer with valid attributes" do
      put 'update', :locale => 'nl', :customer => @valid_attributes
    
      assigns[:customer].should be_valid
    
      response.should be_success
      response.should render_template('customers/edit')
    end

    it "should not update a customer with invalid attributes" do
      put 'update', :locale => 'nl', :customer => @valid_attributes.merge(:email => '')
    
      assigns[:customer].should_not be_valid
    
      response.should be_success
      response.should render_template('customers/edit')
    end

    it "not change the password on blank input" do
      lambda {
        put 'update', :locale => 'nl', :customer => @valid_attributes.merge(:change_password => '1', :new_password => '', :new_password_confirmation => '')
      }.should_not change(customers(:customer_one), :password)
    
      assigns[:customer].should have(:no).error_on(:new_password)
    
      response.should be_success
      response.should render_template('customers/edit')
    end

    it "should not update the password with a password that's too short" do
      lambda {
        put 'update', :locale => 'nl', :customer => @valid_attributes.merge(:change_password => '1', :new_password => 'xxx', :new_password_confirmation => 'xxx')
      }.should_not change(customers(:customer_one), :password)
    
      assigns[:customer].should have(1).error_on(:new_password)
    
      response.should be_success
      response.should render_template('customers/edit')
    end

    it "should not update the password with an invalid password confirmation" do
      lambda {
        put 'update', :locale => 'nl', :customer => @valid_attributes.merge(:change_password => '1', :new_password => 'xxxxxx', :new_password_confirmation => 'yyyyyy')
      }.should_not change(customers(:customer_one), :password)
    
      assigns[:customer].should have(1).error_on(:new_password)
    
      response.should be_success
      response.should render_template('customers/edit')
    end

    it "should update the password with valid input" do
      put 'update', :locale => 'nl', :customer => @valid_attributes.merge(:change_password => '1', :new_password => 'new_password', :new_password_confirmation => 'new_password')
    
      assigns[:customer].should be_valid
      assigns[:customer].password.should == Customer.encrypt_password('new_password')
    
      response.should be_success
      response.should render_template('customers/edit')
    end

  end

  describe CustomersController, "send forgot password email" do

    before do
      ActionMailer::Base.deliveries.clear
    end

    it "should show the forgot password form" do
      get 'forgot_password', :locale => 'nl'
      
      response.should be_success
      response.should render_template('customers/forgot_password')
    end

    it "should not send the email if the email address is unknown" do
      post 'send_password_link', :email => 'nothing', :locale => 'nl'
      
      flash[:forgot_password].should == 'Email address not found'
      
      response.should be_success
      response.should render_template('customers/forgot_password')
    end

    it "should send the email if the email address is known" do
      lambda {
        post 'send_password_link', :email => 'customer_one@somewhere.com', :locale => 'nl'
      }.should change(ActionMailer::Base.deliveries, :length).by(1)
      
      flash[:forgot_password].should == 'Email sent'
      
      customer = customers(:customer_one)
      customer.new_password_token.should_not be_nil
      customer.new_password_token_set_at.should_not be_nil
      
      response.should be_success
      response.should render_template('customers/forgot_password')
    end

    it "should display a message if a wrong password code is used" do
      get 'choose_new_password', :token => 'nonsense', :locale => 'nl'
      assigns[:customer].should be_nil
      
      response.should be_success
      response.should render_template('customers/choose_new_password')
    end

  end

  describe CustomersController, "change password with token" do

    before do
      @customer = customers(:customer_one)
      @customer.update_attributes!(:new_password_token => 'token', :new_password_token_set_at => Time.current)
    end

    it "should display a message if an expired password code is used" do
      @customer.update_attribute(:new_password_token_set_at, Time.current.months_ago(1))
    
      get 'choose_new_password', :token => 'token', :locale => 'nl'
    
      assigns[:customer].should be_nil
    
      response.should be_success
      response.should render_template('customers/choose_new_password')
    end

    it "should display the choose password form if a right code is provided" do
      get 'choose_new_password', :token => 'token', :locale => 'nl'
    
      assigns[:customer].should == @customer
    
      response.should be_success
      response.should render_template('customers/choose_new_password')
    end

    it "should not change the password if the code is invalid" do
      post 'set_new_password', :token => 'nonsense', :customer => {}, :locale => 'nl'
    
      assigns[:customer].should be_nil
    
      response.should be_success
      response.should render_template('customers/choose_new_password')
    end

    it "should not change the password if the password confirmation is not right" do
      post 'set_new_password', :token => 'token', :customer => {:new_password => 'newpassword', :new_password_confirmation => ''}, :locale => 'nl'
    
      assigns[:customer].should == @customer
      assigns[:customer].should_not be_valid
      assigns[:message].should == 'Check your input'
    
      response.should be_success
      response.should render_template('customers/choose_new_password')
    end

    it "should change the password if the password confirmation is right" do
      post 'set_new_password', :token => 'token', :customer => {:new_password => 'newpassword', :new_password_confirmation => 'newpassword'}, :locale => 'nl'
    
      customer = assigns[:customer]
      customer.should == @customer
      customer.should be_valid
    
      customer.new_password_token.should be_nil
      customer.new_password_token_set_at.should be_nil
    
      response.should be_redirect
      response.should redirect_to(new_session_path)
    end
    
  end

end