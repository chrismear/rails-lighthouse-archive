class A < ActiveRecord::Base
  belongs_to :b
  
  named_scope :with_b_name, lambda { |args| 
    return { 
      :joins => "INNER JOIN `bs` ON `bs`.id = `as`.b_id",  
      :conditions => ["bs.name = ?", args]
    }
  }

  named_scope :with_b_lame, lambda { |args| 
    return { 
      :joins => "INNER JOIN `bs` ON `bs`.id = `as`.b_id",  
      :conditions => ["bs.name = ?", args]
    }
  }

  named_scope :with_b_tame, lambda { |args| 
    return { 
      :joins => "INNER JOIN `bs` ON `bs`.id = `as`.b_id",  
      :conditions => ["bs.tame = ?", args]
    }
  }

end
