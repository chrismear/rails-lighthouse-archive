class User < ActiveRecord::Base
has_many :UserGroups
has_many :Groups, :through=>:UserGroups
end
