class Thing < ActiveRecord::Base
end
