require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe OrderItemsController do

  integrate_views

  fixtures :products, :product_variations, :product_units, :orders, :order_items, :product_collections

  it "should show index without an order" do
    session[:order_id].should be_nil
    
    get 'index', :locale => 'nl'
    
    assigns[:order].should be_nil
    
    response.should be_success
    response.should render_template('order_items/index')
  end

  it "should get an order from the session if it exists" do
    session[:order_id] = orders(:cart_1).id
    
    get 'index', :locale => 'nl'
    
    assigns[:order].should == orders(:cart_1)
    
    response.should be_success
    response.should render_template('order_items/index')
  end

  it "should create a new order item and a new order if the order does not exist" do
    session[:order_id].should be_nil
    
    lambda {
      post 'create', :locale => 'nl', :order_item => {:product_unit_id => product_units(:dress_1_red_m).id, :quantity => 1}
    }.should change(Order, :count).by(1)
    
    assigns[:order].state.should == :cart
    assigns[:order].order_items.should have(1).item
    assigns[:order].order_items.first.product_unit.should == product_units(:dress_1_red_m)
    
    response.should be_success
    response.should render_template('order_items/create')
  end

  it "should create a new order item for an existing order" do
    session[:order_id] = orders(:cart_1).id
    
    lambda {
      post 'create', :locale => 'nl', :order_item => {:product_id => products(:dress_1).id, :product_unit_id => product_units(:dress_1_red_m).id, :quantity => 1}
    }.should change(orders(:cart_1).order_items, :count).by(1)
    
    assigns[:order].should == orders(:cart_1)
    assigns[:order_item].product_unit.should == product_units(:dress_1_red_m)
    
    response.should be_success
    response.should render_template('order_items/create')
  end

  it "should create an order item for all product's first units in a product collection" do
    session[:order_id] = orders(:cart_1).id
    
    lambda {
      post 'create', :locale => 'nl', :product_collection_id => product_collections(:collection_one)
    }.should change(orders(:cart_1).order_items, :count).by(2)
    
    response.should be_success
    response.should render_template('order_items/create')
  end

  it "should destroy an order item" do
    session[:order_id] = orders(:cart_1).id
    
    lambda {
      delete 'destroy', :locale => 'nl', :id => order_items(:cart_1_dress_1_red_m)
    }.should change(OrderItem, :count).by(-1)
    
    assigns[:order_item].should_not be_nil
    
    response.should be_success
    response.should render_template('order_items/destroy') 
  end

  it "should empty all order items for this order" do
    session[:order_id] = orders(:cart_1).id
    
    lambda {
      post 'empty', :locale => 'nl'
    }.should change(OrderItem, :count).by(-2)
    
    response.should be_success
    response.should render_template('order_items/empty') 
  end

end