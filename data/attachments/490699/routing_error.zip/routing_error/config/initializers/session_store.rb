# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_routing_error_session',
  :secret      => '39cfa871b5168fa7ec9378f1b0f9850b5c1fd0f6fbc76c478dd61a80a5bd29fbee5c37019815d5b5b173c30df4c31d22cf04092e4eb0e40fbd6a592037200545'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
