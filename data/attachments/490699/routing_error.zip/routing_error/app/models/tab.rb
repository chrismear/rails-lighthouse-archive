class Tab < ActiveRecord::Base
end
