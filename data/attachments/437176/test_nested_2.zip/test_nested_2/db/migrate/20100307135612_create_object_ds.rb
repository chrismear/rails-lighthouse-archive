class CreateObjectDs < ActiveRecord::Migration
  def self.up
    create_table :object_ds do |t|
      t.string :name

      t.timestamps
    end
  end

  def self.down
    drop_table :object_ds
  end
end
