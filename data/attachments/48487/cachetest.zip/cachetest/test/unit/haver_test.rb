require 'test_helper'

class HaverTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  def test_find_or_create
    haver = Haver.create
    
    # evaluating once so it will cache haver.belongers
    assert_equal(0,haver.belongers.length) 
    
    # find_or_create doesn't clear the cache when it creates
    haver.belongers.find_or_create_by_name("Joe")
    
    # which gives us an interesting anomaly!
    assert_equal(1,haver.belongers.count)
    assert_equal(1,haver.belongers.length)
  end
end
