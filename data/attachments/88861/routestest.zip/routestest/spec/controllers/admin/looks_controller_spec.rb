require File.expand_path(File.dirname(__FILE__) + '/../../spec_helper')

describe Admin::LooksController do

  integrate_views

  fixtures :products, :product_translations, :looks, :look_categories

  it "should get index" do
    get 'index'
    
    assigns[:looks].should_not be_nil
    assigns[:looks].should have(1).items
    
    response.should be_success
    response.should render_template('admin/looks/index')
  end

  it "should get new" do
    get 'new'
    
    assigns[:look].should_not be_nil
    
    response.should be_success
    response.should render_template('admin/looks/new')
  end

  it "should create a new look with valid params" do
    post 'create', :look => {:title => 'new', :text => 'new', :items => 'items', :name => 'Henk', :image => get_test_file, :look_category => look_categories(:casual)}
    
    assigns[:look].should be_valid
    assigns[:look].image.url.should_not be_nil
    
    response.should redirect_to(admin_looks_path())
  end

  it "should not create a new look with invalid params" do
    post 'create', :look => {:title => '', :text => '', :items => '', :name => '', :image => get_test_file}
    
    assigns[:look].should_not be_valid
    assigns[:look].should have(1).error_on(:title)
    assigns[:look].should have(1).error_on(:text)
    assigns[:look].should have(1).error_on(:look_category)
    
    response.should render_template('admin/looks/new')
  end

  it "should get edit" do
    get 'edit', :id => looks(:look_one)
    
    assigns[:look].should eql(looks(:look_one))
    
    response.should be_success
    response.should render_template('admin/looks/edit')
  end

  it "should update a look with valid params" do
    post 'update', :look => {:title => 'new', :text => 'new', :items => 'items', :name => 'Henk', :look_category => look_categories(:casual)}, :id => looks(:look_one)
    
    assigns[:look].should be_valid
    
    response.should redirect_to(admin_looks_path())
  end

  it "should not update a ook with invalid params" do
    post 'update', :look => {:title => 'new', :text => '', :items => 'items', :name => 'Henk'}, :id => looks(:look_one)
    
    assigns[:look].should_not be_valid

    response.should render_template('admin/looks/edit')
  end

  it "should destroy a look" do
    lambda {
      delete 'destroy', :id => looks(:look_one)
    }.should change(Look, :count).by(-1)
    
    response.should be_success
    response.should render_template('admin/looks/destroy') 
  end

end