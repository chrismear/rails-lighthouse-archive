# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Aaron::Application.config.secret_token = 'c36d38cf0954feb799015aaed982a9e9dedb4912e0752b6c413a0b65a1f47827cc4dac09cf03bdd062a7d1d92cf5c8d69b55653426d1688d1ff17213eb93ed63'
