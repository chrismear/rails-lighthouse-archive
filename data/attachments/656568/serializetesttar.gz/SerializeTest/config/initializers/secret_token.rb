# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SerializeTest::Application.config.secret_token = '0a178bef49cb7241699e120f12ceb4d186929edf1d94bddd84f4ddfd4664bba2f00a42701346cc962327f5812f1236f2eaf4fce006cd7e62378ceff9318b8dbb'
