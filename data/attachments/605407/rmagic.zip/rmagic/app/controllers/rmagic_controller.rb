class RmagicController < ApplicationController

  require 'RMagick'
  include Magick


  def index

    img = Magick::Image.read(File.join(Rails.public_path, 'images/test.jpg')).first

    send_data(img.to_blob, { :type => 'image/jpeg', :disposition => "inline" })

  end

end

