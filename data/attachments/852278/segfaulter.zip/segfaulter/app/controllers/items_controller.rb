class ItemsController < ApplicationController
  
  def index
    RubyProf.profile do
      1000.times { Item.create }
    end
  end
  
end