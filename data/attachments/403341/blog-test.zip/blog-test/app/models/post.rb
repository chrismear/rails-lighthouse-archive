class Post < ActiveRecord::Base
  has_many :comments
  
  accepts_nested_attributes_for :comments
  
  def before_validation
    p "post_before_validation - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def before_validation_on_create
    p "post_before_validation_on_create - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def before_validation_on_update
    p "post_before_validation_on_update - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def after_validation
    p "post_after_validation - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def after_validation_on_create
    p "post_after_validation_on_create - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def after_validation_on_update
    p "post_after_validation_on_update - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def before_save
    p "post_before_save - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def before_create
    p "post_before_create - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def before_update
    p "post_before_update - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def after_create
    p "post_after_create - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def after_update
    p "post_after_update - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
  def after_save
    p "post_after_save - #{object_id}"
    puts "#{comments} #{comments.count}"
  end
end
