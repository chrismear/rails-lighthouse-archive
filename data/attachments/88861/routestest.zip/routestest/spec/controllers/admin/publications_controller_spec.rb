require File.expand_path(File.dirname(__FILE__) + '/../../spec_helper')

describe Admin::PublicationsController do

  integrate_views

  fixtures :products, :publications, :product_translations

  it "should index publications" do
    get 'index'
    
    assigns[:publications].should have(3).items
    
    response.should be_success
    response.should render_template('admin/publications/index')
  end

  it "should get new" do
    get 'new'
    
    response.should be_success
    response.should render_template('admin/publications/new')
  end

  it "should create new publication with valid params" do
    post 'create', :publication => {:name => 'Publication 1', :description => 'A publication', :product_id => products(:dress_1).id, :thumb => get_test_file, :full => get_test_file}
    
    assigns[:publication].should be_valid
    assigns[:publication].product.should == products(:dress_1)
    assigns[:publication].thumb.should_not be_nil
    assigns[:publication].full.should_not be_nil
    
    response.should redirect_to(admin_publications_path)
  end

  it "should not create new publication with invalid params" do
    post 'create', :publication => {}
    
    assigns[:publication].should_not be_valid
    
    response.should be_success
    response.should render_template('admin/publications/new')
  end

  it "should get edit" do
    get 'edit', :id => publications(:magazine)
    
    assigns[:publication].should_not be_nil
    
    response.should be_success
    response.should render_template('admin/publications/edit')
  end

  it "should update a publication with valid params" do
    put 'update', :publication => {:name => 'Publication 1', :description => 'A publication', :product_id => products(:dress_1).id, :thumb => get_test_file, :full => get_test_file}, :id => publications(:magazine)
    
    assigns[:publication].should be_valid
    assigns[:publication].product.should == products(:dress_1)
    assigns[:publication].thumb.should_not be_nil
    assigns[:publication].full.should_not be_nil
    
    response.should redirect_to(admin_publications_path)
  end

  it "should destroy a publication" do
    lambda {
      post 'destroy', :id => publications(:magazine)
    }.should change(Publication, :count).by(-1)
    
    response.should be_success
    response.should render_template('admin/publications/destroy')
  end

end