class AddUserIdToListing < ActiveRecord::Migration
  def self.up
    add_column :listings, :user_id, :integer, :null => false
  end

  def self.down
    remove_column :listings, :user_id
  end
end
