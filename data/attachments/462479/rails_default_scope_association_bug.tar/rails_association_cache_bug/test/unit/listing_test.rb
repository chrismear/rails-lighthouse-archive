require File.dirname(__FILE__) + '/../test_helper.rb'

class ListingTest < ActiveSupport::TestCase
  def test_has_comments
    assert listings(:owner_listing).comments
  end
  
  def test_belongs_to_user
    assert_equal listings(:owner_listing).user, users(:owner)
  end
  
  def test_location
    assert_equal listings(:owner_listing).location, "4278 Greybrook Cres, Mississauga, Ontario, L4W 3G7"
  end
  
  def test_can_rate
    assert !listings(:owner_listing).can_rate?(users(:user), nil)
    assert listings(:owner_listing_2).can_rate?(users(:user), nil)
  end
  
  def test_can_rate_with_no_rates
    assert listings(:owner_listing_2).can_rate?(users(:moderator), nil)
  end
  
  def test_can_rate_with_user
    assert !listings(:owner_listing_2).can_rate?(nil, nil)
  end
end
