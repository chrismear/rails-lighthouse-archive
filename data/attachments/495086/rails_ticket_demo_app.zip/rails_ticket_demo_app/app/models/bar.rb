class Bar < ActiveRecord::Base

  has_many :foos, :through => :foo_bar_joins
  has_many :foo_bar_joins
  
end
