class Expense < ActiveRecord::Base
  has_one :expense_reimbursement
end
