module TestMod
  def self.included m
    return unless m < ActionController::Base
    m.helper_method :tst_helper
  end
  def tst_helper
    raise "test"
  end
end