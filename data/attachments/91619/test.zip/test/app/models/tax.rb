class Tax < ActiveRecord::Base
end
