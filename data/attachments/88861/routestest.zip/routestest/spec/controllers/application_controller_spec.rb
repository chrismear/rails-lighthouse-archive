require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe ApplicationController do

  fixtures :customers, :orders, :order_items, :categories

  before do
    @request = mock(:request)
    controller.stub!(:request).and_return(@request)
  end

  it "should set the locale from the locale param" do
    @request.stub!(:path).and_return('/')
    
    controller.stub!(:params).and_return(:locale => 'fr')
    
    controller.send(:set_locale)
    
    I18n.locale.should == 'fr'
    controller.send(:locale).should == 'fr'
  end

  it "should set the en locale if we're in admin" do
    @request.stub!(:path).and_return('/admin')
    
    controller.send(:set_locale)
    
    I18n.locale.should == 'en'
    controller.send(:locale).should == 'en'
  end

  it "should know if we're in /admin" do
    @request.stub!(:path).and_return('/admin/customers')
    
    controller.send(:in_admin?).should be_true
  end

  it "should know if we're not in /admin" do
    @request.stub!(:path).and_return('/customers')
    
    controller.send(:in_admin?).should be_false
  end

  it "should get the current customer if current_customer_id is set in the session" do
    controller.stub!(:session).and_return(:current_customer_id => customers(:customer_one).id)
    
    controller.send(:current_customer).should == customers(:customer_one)
  end

  it "should not get the current customer if current_customer_id in session is empty" do
    controller.stub!(:session).and_return({})
    
    controller.send(:current_customer).should be_nil
  end

  it "should not load the current customer and clear current_customer_id if current_customer_id is set in the session but the customer record does not exist" do
    controller.stub!(:session).and_return(:current_customert_id => 'nonsense')
    
    controller.send(:current_customer).should be_nil
    session[:current_customer_id].should be_nil
  end

  it "should not do anything if login is required and current_customer does not return nil" do
    controller.stub!(:current_customer).and_return(customers(:customer_one))
    controller.should_not_receive(:render)
    
    controller.send(:login_required)
  end

  it "should render shared/login_required if login is required and current_customer returns nil" do
    controller.stub!(:current_customer).and_return(nil)
    controller.should_receive(:render).with(:template => '/shared/login_required', :layout => 'application')
    
    controller.send(:login_required)
  end

  it "should load a category" do
    controller.stub!(:params).and_return(:category_id => categories(:dresses).id)
    
    controller.send(:load_category).should == categories(:dresses)
  end

  it "should load an order from session" do
    controller.stub!(:session).and_return(:order_id => orders(:cart_1).id)
    
    controller.send(:load_order).should == orders(:cart_1)
  end

  it "should not load an order from session if order_id is not set in the session" do
    controller.stub!(:session).and_return({})
    
    controller.send(:load_order).should be_nil
  end

  it "should not load an order and clear order_id if order_id is set in the session but the order record does not exist" do
    controller.stub!(:session).and_return(:order_id => 'nonsense')
    
    controller.send(:load_order).should be_nil
    session[:order_id].should be_nil
  end

  describe ApplicationController, "currency" do

    before do
      configure_shop
    end

    it "should get the main currency if there's none in the session" do
      controller.stub!(:in_admin?).and_return(false)
      
      controller.send(:currency).should == 'euro'
    end

    it "should get the currency from the session" do
      controller.stub!(:in_admin?).and_return(false)
      controller.stub!(:session).and_return(:currency => 'usd')
      
      controller.send(:currency).should == 'usd'
    end

    it "should return euro if we're in the admin" do
      controller.stub!(:in_admin?).and_return(true)
      
      controller.send(:currency).should == 'euro'
    end

  end

end