class Post
  fail
end
