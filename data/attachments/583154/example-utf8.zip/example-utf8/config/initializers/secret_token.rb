# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '02655e8daf6d4cbae4e52a50137e34d43c3603fb5a0e6f69556319edb1400016c9331e29686bd6281921b437b9601c0bdf34c2871f6c8b21ea98f77d36df844a'
