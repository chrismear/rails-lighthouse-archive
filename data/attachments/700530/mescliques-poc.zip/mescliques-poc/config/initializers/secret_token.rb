# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MescliquesPoc::Application.config.secret_token = 'd6e4e0b20ec4aa6f4782033d744b6cc15141e1b6944c9491ca917107c1e32ac8d6a6c21ba4f67cd9fca8358142fe96cb31c32a1345316ea430b7114df7d50398'
