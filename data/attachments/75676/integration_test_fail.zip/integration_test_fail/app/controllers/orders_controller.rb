class OrdersController < ApplicationController
  
  def add_to_cart
    @product = Product.find(params[:id])
    @cart << @product
    
    respond_to do |format|
      format.html { redirect_to product_path(@product)}
    end
  end
  
end
