class Client < ActiveRecord::Base
end
