class Page < ActiveRecord::Base
	belongs_to :book
end
