# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_opt_lck_nest_session',
  :secret      => '0a75006bc94b364da6518b289b64f5de90859402a492b61784e02bb1c78aa1dee39689f7a17c4851b11550b3416476ab90c7f46b548d39c775782c9b19917d2c'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
