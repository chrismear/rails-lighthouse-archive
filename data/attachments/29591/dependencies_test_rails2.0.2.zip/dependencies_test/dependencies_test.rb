# CHANGE THIS to point at a development version of active_record (where ever that maybe)
require "rubygems"
require "active_record"

Dependencies.load_paths.push(".")
ActiveRecord::Base.establish_connection(:adapter => "sqlite3", :database  => "dependencies_test.db")

conn = ActiveRecord::Base.connection
if conn.tables.include?("my_models")
  conn.drop_table("my_models")
end
conn.create_table(:my_models) do |t| end

# The code below is copied exactly from dependencies.rb the only
# line added is the one between ***************************
module Dependencies #:nodoc:

  def require_or_load(file_name, const_path = nil)
    log_call file_name, const_path
    file_name = $1 if file_name =~ /^(.*)\.rb$/
    expanded = File.expand_path(file_name)
    return if loaded.include?(expanded)

    # Record that we've seen this file *before* loading it to avoid an
    # infinite loop with mutual dependencies.
    loaded << expanded
# *****************************************
sleep 0.01 if expanded.include?("my_model")
# *****************************************

    begin
      if load?
        log "loading #{file_name}"

        # Enable warnings iff this file has not been loaded before and
        # warnings_on_first_load is set.
        load_args = ["#{file_name}.rb"]
        load_args << const_path unless const_path.nil?

        if !warnings_on_first_load or history.include?(expanded)
          result = load_file(*load_args)
        else
          enable_warnings { result = load_file(*load_args) }
        end
      else
        log "requiring #{file_name}"
        result = require file_name
      end
    rescue Exception
      loaded.delete expanded
      raise
    end

    # Record history *after* loading so first load gets warnings.
    history << expanded
    return result
  end

end

thread1 = Thread.new {
  begin
    rows = MyModel.find(:all)
  rescue Exception => e
    p "thread1"
    p e
  end
}

thread2 = Thread.new {
  begin
    rows = MyModel.find(:all)
  rescue Exception => e
    p "thread2"
    p e
  end
}

thread1.join
thread2.join