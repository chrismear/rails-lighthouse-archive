require 'test_helper'

class ExpenseReimbursementsControllerTest < ActionController::TestCase
  setup do
    @expense_reimbursement = expense_reimbursements(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:expense_reimbursements)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create expense_reimbursement" do
    assert_difference('ExpenseReimbursement.count') do
      post :create, :expense_reimbursement => @expense_reimbursement.attributes
    end

    assert_redirected_to expense_reimbursement_path(assigns(:expense_reimbursement))
  end

  test "should show expense_reimbursement" do
    get :show, :id => @expense_reimbursement.to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => @expense_reimbursement.to_param
    assert_response :success
  end

  test "should update expense_reimbursement" do
    put :update, :id => @expense_reimbursement.to_param, :expense_reimbursement => @expense_reimbursement.attributes
    assert_redirected_to expense_reimbursement_path(assigns(:expense_reimbursement))
  end

  test "should destroy expense_reimbursement" do
    assert_difference('ExpenseReimbursement.count', -1) do
      delete :destroy, :id => @expense_reimbursement.to_param
    end

    assert_redirected_to expense_reimbursements_path
  end
end
