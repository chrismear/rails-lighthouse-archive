require 'test_helper'

class HomeControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
  end

  test "should get creer" do
    get :creer
    assert_response :success
  end

  test "should get recup-pwd" do
    get :recup-pwd
    assert_response :success
  end

end
