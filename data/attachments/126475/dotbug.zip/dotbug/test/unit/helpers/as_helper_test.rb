require 'test_helper'

class AsHelperTest < ActionView::TestCase
end
