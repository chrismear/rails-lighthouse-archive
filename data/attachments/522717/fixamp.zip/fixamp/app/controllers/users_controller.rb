class UsersController < ApplicationController

  def index
    
  end

  def ajax_route
    
  end

  def profile
    render :text => params.inspect
  end

end
