# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'd9fef1fd8256e4640f933bc010fd71dfda76f3ee08494cba690895713ce2a0868b9320f3b0ceab1d268000249ebfc3e2b1946c176aa81f8d074c0a276ca70edd';
