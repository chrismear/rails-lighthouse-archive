# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '1728694f8f88a1862e906001afca63ca65336b1b2824d2ac7eda37960432c5fe90f32e55e686c5a6c70cbf544c38e30d35556f7b3a61ba1893da4edc1b41c0d5';
