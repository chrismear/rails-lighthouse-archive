# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_simplecase_session',
  :secret      => '1363d30dd3c75d6b2a4226ed9c636b2b1dfff8a81eb25ecd8e8bb1992d26900a3627a762e5541e986c8f39c69065ec8712896da723d5dfc466f8d863fee42ef4'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
