ActionController::Routing::Routes.draw do |map|
# standard namspaced  nested routes
#  map.namespace :admin do |admin|
#    admin.resources :parents do |parent|
#      parent.resources :children
#    end
#  end

# shallow namespaced nested routs
  map.namespace :admin  do |admin|
    admin.resources :parents, :shallow => true do |parent|
      parent.resources :children
    end
  end
  
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'
end
