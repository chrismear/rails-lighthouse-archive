require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe PublicationsController do

  integrate_views

  fixtures :publications, :products, :product_translations

  it "should get index" do
    get 'index', :locale => 'nl'
    
    assigns[:publications].should have(3).items
    
    response.should be_success
    response.should render_template('publications/index')
  end

  it "should get index with a product" do
    get 'index', :locale => 'nl', :product_id => products(:dress_1).id
    
    assigns[:publications].should have(1).item
    assigns[:publications].should include(publications(:magazine))
    
    get 'index', :locale => 'nl', :product_id => products(:dress_2).id
    
    assigns[:publications].should have(2).items
    assigns[:publications].should include(publications(:tv))
    assigns[:publications].should include(publications(:internet))
    
    response.should be_success
    response.should render_template('publications/index')
  end

end