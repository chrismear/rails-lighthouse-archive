require File.dirname(__FILE__) + '/../spec_helper'

describe Project do
  describe "when save with nested attributes" do
    it "should not have STALE object error and :lock_version should be 0" do
      @attr = { :name => 'test',
                :tasks_attributes => {
                  "new_1" => {:name => "task 1"},
                  "new_2" => {:name => "task 2"},
                  "new_3" => {:name => "task 3"}
                     } }
      @project = Project.new
      lambda { @project.update_attributes(@attr) }.should_not raise_error
      @project.reload
      @project.lock_version.should == 0
    end

    it "should not have STALE object error and :lock_version should be 7" do
      @project = Project.create!(:name => "project 1")
      @task1 = Task.create!(:project_id => @project.id, :name => "task 1")
      @project.reload
      @project.lock_version.should == 1
      @task2 = Task.create!(:project_id => @project.id, :name => "task 2")
      @project.reload
      @project.lock_version.should == 2
      @task3 = Task.create!(:project_id => @project.id, :name => "task 3")
      @project.reload
      @project.lock_version.should == 3
      @project.reload
      @attr = { :name => "project 1c", :tasks_attributes => {
                  "1" => {:id => "#{@task2.id}", :name => "task 2c"},
                  "2" => {:id => "#{@task1.id}", :name => "task 1" },
                  "3" => {:id => "#{@task3.id}", :_destroy => true},
                  "4" => {:name => "task 4"}
                     } }
      lambda { @project.update_attributes(@attr) }.should_not raise_error
      @project.reload
      @project.lock_version.should == 7
    end

    it "should not have STALE object error and :lock_version should be 0" do
      @attr = { :name => 'test' }
      @project = Project.new(@attr)
      @project.tasks.build(:name => "task 1")
      @project.tasks.build(:name => "task 2")
      lambda {@project.save!}.should_not raise_error
      @project.reload
      @project.lock_version.should == 0
      @project.tasks[1].destroy
      @project.reload
      @project.lock_version.should == 1
    end

    it "should not have STALE object error and :lock_version should be 4" do
      @project = Project.create!(:name => "project 1")
      @task1 = Task.create!(:project_id => @project.id, :name => "task 1")
      @project.reload
      @project.lock_version.should == 1
      @task2 = Task.create!(:project_id => @project.id, :name => "task 2")
      @project.reload
      @project.lock_version.should == 2
      @project.tasks[1].name = "changed task 2"
      @project.tasks.build(:name => "task 3")
      lambda {@project.save!}.should_not raise_error
      @project.reload
      @project.lock_version.should == 4
    end
  end
end

