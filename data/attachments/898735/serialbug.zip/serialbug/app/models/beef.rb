class Beef < ActiveRecord::Base
  serialize :details
end
