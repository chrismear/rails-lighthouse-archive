class Foo < ActiveRecord::Base

  ## AS IS THIS WILL CREATE TWO "LINKAGE" RECORDS EVERY TIME A FOO OBJECT IS CREATED (it should only create one)
  
  ## THIS IS HAPPENING BECAUSE OF THE CALL TO "bars.count" IN THE CALLBACK
  ## calling bars.count triggers an internal AR callback, "autosave_associated_records_for_bars", which causes a second Linkage object to be created

  after_create  :blah
  has_many  :linkages
  has_many  :bars, :through => :linkages, :source => :thing, :source_type => 'Bar'

  def blah
    b = Bar.last
    Linkage.create!(:foo => self, :thing => b)
    bars.count
  end
  
end