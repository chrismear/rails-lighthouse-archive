require 'test_helper'

class ThingsControllerTest < ActionController::TestCase
  def test_show_with_invalid_id_should_set_flash
    get :show, :id => nil
    assert_equal 'That thing could not be found', flash[:error]
  end
end
