class CreateComments < ActiveRecord::Migration
  def self.up
    create_table :comments, :force => true do |t|
      t.column :comment, :string, :null => false
      t.column :listing_id, :integer, :null => false
      t.column :user_id, :integer, :null => false
      t.timestamps
    end

    add_index :comments, ["user_id"]

  end

  def self.down
    drop_table :comments
  end
end
