class B < ActiveRecord::Base
  belongs_to :a
  belongs_to :c
  default_scope :order => "created_at DESC"
end

