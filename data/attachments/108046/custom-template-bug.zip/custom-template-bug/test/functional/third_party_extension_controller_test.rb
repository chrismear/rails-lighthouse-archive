require File.expand_path(File.join(File.dirname(__FILE__), "..", 'test_helper'))

class ThirdPartyExtensionControllerTest < ActionController::TestCase

  def test_index_should_return_the_proper_text_when_there_is_just_a_template
    get :template_with_no_action
    assert_equal "it works", @response.body
  end

  def test_index_should_return_the_proper_text_when_there_is_a_template_with_and_empty_action
    get :template_with_empty_action
    assert_equal "it works", @response.body
  end

  def test_index_should_return_the_proper_text_with_a_template_and_an_action_using_template_with_render_template_with_no_extension
    get :template_with_render_template
    assert_equal "it works", @response.body
  end

  def test_index_should_return_the_proper_text_with_a_template_and_an_action_using_template_with_render_template_with_extension
    get :template_with_render_template_with_extension
    assert_equal "it works", @response.body
  end

end
