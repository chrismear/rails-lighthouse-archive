class Frob < ActiveRecord::Base
end
