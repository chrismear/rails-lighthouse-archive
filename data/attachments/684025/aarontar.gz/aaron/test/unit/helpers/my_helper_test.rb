require 'test_helper'

class MyHelperTest < ActionView::TestCase
end
