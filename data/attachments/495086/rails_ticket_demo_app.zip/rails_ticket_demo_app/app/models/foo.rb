class Foo < ActiveRecord::Base

  has_many :bars, :through => :foo_bar_joins
  has_many :foo_bar_joins

end
