require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe PagesController do

  integrate_views

  fixtures :pages, :page_content_blocks, :page_images, :categories

  it "should show a page" do
    get :show, :id => 'home', :locale => 'nl'
    
    assigns[:page].should == pages(:home)
    
    response.should be_success
    response.should render_template('pages/show')
  end

  it "should show a 404 page" do
    get :show, :id => 'nonsense', :locale => 'nl'
    
    assigns[:page].should be_nil
    
    response.code.should == '404'
    response.should render_template('pages/show')
  end

end