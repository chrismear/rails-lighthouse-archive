class Household < ActiveRecord::Base
  has_many :household_people
  has_many :people, :through => :household_people
end
