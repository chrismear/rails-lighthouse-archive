I18n.default_locale = 'cz'
I18n.locale = I18n.default_locale
I18n.load_path << "#{RAILS_ROOT}/config/locales/cz.rb"
