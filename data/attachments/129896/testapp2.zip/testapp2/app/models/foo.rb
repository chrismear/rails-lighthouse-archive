class Foo < ActiveRecord::Base

  ## AS IS THIS WILL CREATE TWO "LINKAGE" RECORDS EVERY TIME A FOO OBJECT IS CREATED (it should only create one)
  
  ## BUT IT WILL WORK AS EXPECTED IF YOU DO EITHER OF THESE TWO THINGS
  ##    (a) remove the "puts" statement in the callback function
  ## OR (b) reove the "after_create :blah" line and just change the blah method to be named "after_create"

  after_create  :blah
  has_many  :linkages
  has_many  :bars, :through => :linkages, :source => :thing, :source_type => 'Bar'

  def blah
    b = Bar.last
    Linkage.create!(:foo => self, :thing => b)
    puts "\nbars count: #{bars.count}\n"
  end
  
end