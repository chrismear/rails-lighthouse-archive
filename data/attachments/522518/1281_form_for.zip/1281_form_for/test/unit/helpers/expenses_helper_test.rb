require 'test_helper'

class ExpensesHelperTest < ActionView::TestCase
end
