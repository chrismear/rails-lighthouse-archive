class User < ActiveRecord::Base
	serialize :preferences, UserPreferences
	
	before_save :make_preferences_initialized
	
  private
  
  def make_preferences_initialized
  	write_attribute(:preferences, UserPreferences.new) if read_attribute(:preferences).nil?
  end
  
  
end
