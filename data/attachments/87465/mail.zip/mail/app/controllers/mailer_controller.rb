class MailerController < ApplicationController
  
  def go
    Mail.deliver_daily_report
    render :text => "Sent!"
  end

end
