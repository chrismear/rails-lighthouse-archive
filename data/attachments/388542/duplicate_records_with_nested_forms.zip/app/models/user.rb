class User < ActiveRecord::Base
	has_many :account_users
	has_many :accounts, :through => :account_users

	accepts_nested_attributes_for :accounts

end
