class Person < ActiveRecord::Base

  has_many :household_people
  has_many :households, :through => :household_people
  
  named_scope :in, lambda {|people|
    {
      :conditions => ["id in (?)", people]
    }
  }
  
end
