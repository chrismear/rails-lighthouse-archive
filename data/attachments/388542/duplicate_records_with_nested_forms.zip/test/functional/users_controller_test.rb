require 'test_helper'

class UsersControllerTest < ActionController::TestCase

  test "create" do
    post :create, :user => {:name => 'Joe' }
    assert_response :success
    assert @response.body.include?('ok')
    usr = User.find(:first)
    assert_equal 'Joe', usr.name
    assert_equal 0, Account.count
  end


  test "create with account" do
    post :create, :user => {:name => 'Joe', :accounts_attributes => {'0' => {:name => 'mycompany'  }}}
    assert_response :success
    assert @response.body.include?('ok')

    usr = User.find(:first)
    assert_equal 'Joe', usr.name

    assert_equal 1, Account.count
    acc = Account.find(:first)
    assert_equal 'mycompany', acc.name

    assert_equal 1, AccountUser.count
    auser = AccountUser.find(:first)
    assert_equal acc.id, auser.account_id
    assert_equal usr.id, auser.user_id
  end
end
