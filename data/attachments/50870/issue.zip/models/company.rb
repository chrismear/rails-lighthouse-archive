# 
# To change this template, choose Tools | Templates
# and open the template in the editor.
 

class Company < ActiveRecord::Base
  
  has_many :account_associations
  has_many :accounts, :include => :owning_association, :through => :account_associations
end
