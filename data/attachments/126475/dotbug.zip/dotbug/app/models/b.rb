class B < ActiveRecord::Base
  belongs_to :a
end
