require 'test_helper'

class CustomerTest < ActiveSupport::TestCase
  fixtures :customers, :invoices, :line_items

  test "has_many through associations" do
    c = Customer.find :first
    assert !c.nil?
    assert c.customer_alternate_key, 'C7701'

    i = c.invoices.first
    assert !i.nil?
    assert i.customer_foreign_key, 'C7701'
    assert i.invoice_alternate_key, 'I8856'

    l = i.line_items.first
    assert !l.nil?
    assert l.invoice_foreign_key, 'I8856'
    assert l.line_item_alternate_key, 'X1234'

    lc = c.line_items.first
    assert !lc.nil?
    assert lc.invoice_foreign_key, 'I8856'
    assert lc.line_item_alternate_key, 'X1234'
  end
end
