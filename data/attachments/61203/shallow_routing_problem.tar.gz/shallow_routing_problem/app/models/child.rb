class Child < ActiveRecord::Base
end
