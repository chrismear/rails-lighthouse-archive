class LineItem < ActiveRecord::Base
end
