class CreateAuthors < ActiveRecord::Migration
  def self.up
    create_table :authors do |t|
      t.string :first_name
      t.string :last_name

      t.timestamps
    end
    add_column :books, :author_id, :integer
  end

  def self.down
    drop_table :authors
    remove_column :books, :author_id
  end
end
