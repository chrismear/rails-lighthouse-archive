class CreateParentModels < ActiveRecord::Migration
  def self.up
    create_table :parent_models do |t|
      t.string :name

      t.timestamps
    end
  end

  def self.down
    drop_table :parent_models
  end
end
