# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AcceptHeaderTest::Application.config.secret_token = '67f9a86f6479dc9ecebb7858b4be8dd72f4ed6ea180317e94bebb5b98e9f8791e5b66bfe04702cd6b30ee5db7d6dcb0f6ef8865bd6163d828dd74efb1d9d73a3'
