class MultiSaveController < ApplicationController
	def create
		@object = MultiSave.new
	end
	
	def new
		@multi_save = MultiSave.new(params[:multi_save])
		
		@multi_save.save!
		@multi_save.save!
	end
end
