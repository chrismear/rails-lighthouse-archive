# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '35edb36e4af175225db70f21809f5d0baba3ed63be9265a1c2a26ed35c5f093dc450209b243ce548a01eee1dc0f1794bb20c4f59e16499e630f7666b45aa633f'
