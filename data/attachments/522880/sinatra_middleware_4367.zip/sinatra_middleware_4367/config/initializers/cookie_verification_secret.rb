# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '6ab9810fcbaffb9aa7e42b22c0a696168ba213a28c6b43a83117b70d89727b623563b43cdee6e11c23ce1413ac7888d8d282337c9474d002ac78b3c405ce7efa';
