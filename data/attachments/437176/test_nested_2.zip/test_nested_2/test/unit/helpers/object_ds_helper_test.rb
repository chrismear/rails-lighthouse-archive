require 'test_helper'

class ObjectDsHelperTest < ActionView::TestCase
end
