class XmlCachingController < ApplicationController

  caches_action :index_with_cache_from_proc,
    :cache_path => Proc.new { |c| 'xml_content_type_cache_path_through_proc' }
  caches_action :index_with_cache_from_string,
    :cache_path => 'xml_content_type_cache_path_by_string'

  def index_with_cache_from_proc
    headers["Content-Type"] = 'text/xml; charset=UTF-8'
    render :xml => {:foo => 'bar'}
  end

  def index_with_cache_from_string
    index_with_cache_from_proc
  end

end
