class ThingsController < ApplicationController
  def new
    if request.post?
      raise params[:thing].inspect
    end
  end
end
