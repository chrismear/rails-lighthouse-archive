# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_cache_test_session',
  :secret      => 'a7cacf05329754e6b885baf3ba614c5cf13ab15b133d9e3f93d6ddae2171720a921407d9af3720a701a6d85f4b1f91aee9c5cf04d06fc10d56ba3a02d0152574'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
