# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_dotbug_session',
  :secret      => '0958ee960840b325056220f2fccd3d13f7829fce54c667dd92e74ae7767795fc0063c6d07015d3e9fa0d9c8ed05d0b56a6649d4f80250c691b5c83e2d90729c5'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
