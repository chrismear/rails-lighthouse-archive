class Community < ActiveRecord::Base

  named_scope :foo, :conditions => ['communities.id > 5']

end
