class CreateObjectCs < ActiveRecord::Migration
  def self.up
    create_table :object_cs do |t|
      t.string :name
      t.integer :object_b_id

      t.timestamps
    end
  end

  def self.down
    drop_table :object_cs
  end
end
