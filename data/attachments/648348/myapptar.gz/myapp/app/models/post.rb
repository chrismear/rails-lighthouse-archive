class Post < ActiveRecord::Base
  attr_writer :password
end
