# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Bla::Application.config.secret_token = '210d7d9b15a92c95d2ee3e186d0b19b994d16d2b583cf8f3ba5bd1605dd7f71d4e54f7e12388881f77057d48e93cc5c0c10c24c5741171cfb515e2979fdc6569'
