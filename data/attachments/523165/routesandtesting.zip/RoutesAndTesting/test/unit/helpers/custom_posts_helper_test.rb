require 'test_helper'

class CustomPostsHelperTest < ActionView::TestCase
end
