require 'test_helper'

class NoteMailerTest < ActionMailer::TestCase
  def test_foo
    email = NoteMailer.foo.deliver
    assert_match /Message body/, email.encoded
  end
end
