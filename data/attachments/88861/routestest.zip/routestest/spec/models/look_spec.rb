require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe Look do
  
  fixtures :look_categories, :products, :looks

  before(:each) do
    @valid_attributes = {
      :title => 'Title',
      :text => 'Text',
      :look_category => look_categories(:casual)
    }
  end

  it "should create a new instance given valid attributes" do
    Look.create!(@valid_attributes)
  end

  it "should not create anything with invalid attributes" do
    Look.create(@valid_attributes.merge!({:title => ''})).should have(1).error_on(:title)
    Look.create(@valid_attributes.merge!({:text => nil})).should have(1).error_on(:text)
    Look.create(@valid_attributes.merge!({:look_category => nil})).should have(1).error_on(:look_category)
  end

  it "should have valid fixtures" do
    looks(:look_one).should be_valid
  end

  it "should have a list of products" do
    look = looks(:look_one)
    look.products.should include(products(:dress_1))
    look.products.should include(products(:dress_2))
  end

end