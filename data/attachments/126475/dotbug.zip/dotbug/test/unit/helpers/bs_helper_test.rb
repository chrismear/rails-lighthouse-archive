require 'test_helper'

class BsHelperTest < ActionView::TestCase
end
