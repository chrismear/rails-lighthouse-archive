# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = 'a9ef6654dd4fb1888fc53fbc91b29b3adb2cfe7d3148130bc375ec685c9d7a2a904e4ab5b0cfbf9512080044217a00d6c5d798d920fb1fcd1950931ffedddf95'
