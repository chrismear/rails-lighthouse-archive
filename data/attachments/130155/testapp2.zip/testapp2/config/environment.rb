RAILS_GEM_VERSION = '2.2.2' unless defined? RAILS_GEM_VERSION

# Bootstrap the Rails environment, frameworks, and default configuration
require File.join(File.dirname(__FILE__), 'boot')

Rails::Initializer.run do |config|

  config.gem 'sqlite3-ruby', :lib => 'sqlite3'

  config.time_zone = 'Eastern Time (US & Canada)'

  # no regular words or you'll be exposed to dictionary attacks.
  config.action_controller.session = {
    :session_key => '_test_app_session',
    :secret      => 'd0526fd22d5357f40dadfd72c8d9aad3f85a59beb7a64300c60fee65b8f4d71935dadfcdffbc9d0841ed4ae7017c649dd325ae1313f9730588892b59a0ff2986'
  }

  config.after_initialize do

  end
  
end