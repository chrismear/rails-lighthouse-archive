class C < ActiveRecord::Base
  has_many :bs
  has_many :as
end
