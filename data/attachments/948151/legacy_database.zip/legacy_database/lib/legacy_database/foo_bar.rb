module LegacyDatabase
  class FooBar < Base
    set_table_name :foo_bars
    
    belongs_to :foo
    belongs_to :bar
  end
end