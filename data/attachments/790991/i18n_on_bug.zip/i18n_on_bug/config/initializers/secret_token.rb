# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
I18nOnBug::Application.config.secret_token = '23521ad90cb69ebde04fe143205b03d3e444b226fb2f473e40a29bbbcaf730139a619c5363478676aa5617eca9a958e813644cd89151b3e38d199be2f6a4b85c'
