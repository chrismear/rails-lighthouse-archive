class ExpenseReimbursement < ActiveRecord::Base
  belongs_to :expense
end
