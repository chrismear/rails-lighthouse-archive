class Comment < ActiveRecord::Base
  belongs_to :post, :validate => false
  
  def before_validation
    p "comment_before_validation - #{object_id}"
  end
  def before_validation_on_create
    p "comment_before_validation_on_create - #{object_id}"
  end
  def before_validation_on_update
    p "comment_before_validation_on_update - #{object_id}"
  end
  def after_validation
    p "comment_after_validation - #{object_id}"
  end
  def after_validation_on_create
    p "comment_after_validation_on_create - #{object_id}"
  end
  def after_validation_on_update
    p "comment_after_validation_on_update - #{object_id}"
  end
  def before_save
    p "comment_before_save - #{object_id}"
  end
  def before_create
    p "comment_before_create - #{object_id}"
  end
  def before_update
    p "comment_before_update - #{object_id}"
  end
  def after_create
    p "comment_after_create - #{object_id}"
  end
  def after_update
    p "comment_after_update - #{object_id}"
  end
  def after_save
    p "comment_after_save - #{object_id}"
  end
end
