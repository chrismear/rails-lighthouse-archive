class HaversController < ApplicationController
end
