# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
UuidId::Application.config.secret_token = '0c015514a0698659eb83338d15cae364a5231e58f6ceb1436408bafad7adf915ab466ccfca816a7bacd2b02cdcb872d52627e077771159d4073fd57e7f9437df'
