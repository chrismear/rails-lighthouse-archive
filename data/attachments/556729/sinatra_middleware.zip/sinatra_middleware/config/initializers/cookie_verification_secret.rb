# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '53291d9483b198724332ab668da3fa83208a0015c3562964c0756062fdcc641b213cb143e9add21989e725f709b452167c100c22023f77fc5615f14b17a12127';
