class MyController < ApplicationController
  respond_to :html, :js

  def show
    respond_with do |format|
      format.js do
        render(:update) do |page|
          page.replace_html 'content', :partial => "show", :layout => "layouts/jspartial"
        end
      end
      format.html
    end
  end
end
