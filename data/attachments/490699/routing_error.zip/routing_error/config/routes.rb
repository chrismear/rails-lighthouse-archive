ActionController::Routing::Routes.draw do |map|
  
  map.resources :tabs do |tab|
    tab.resources :contacts, :collection => {
      :bar => :get
    }
  end

  map.resources :clients do |client|
    client.resources :contacts, :collection => {
      :foo => :get
    }
  end

  map.root :controller => 'clients', :action => 'root'
  
end
