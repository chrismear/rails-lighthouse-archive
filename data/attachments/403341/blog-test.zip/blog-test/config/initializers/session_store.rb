# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_blog4_session',
  :secret      => '527e7e8ac2d9403dc84c13eb1bd9e4edcf5a1e285d01d81e84fa58e161178664f32da91de88b67e5b5b1c5a00c0f2fbdede7d6480318a2621bd9ee6d538c712b'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
