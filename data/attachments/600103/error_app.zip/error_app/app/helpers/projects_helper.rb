module ProjectsHelper

  def add_task_link(form_builder)
    link_to_function 'add a task' do |page|
      form_builder.fields_for :tasks, Task.new do |f|
        page.insert_html :bottom, :tasks, :partial => 'task', :locals => { :form => f }
      end
    end
  end

end

