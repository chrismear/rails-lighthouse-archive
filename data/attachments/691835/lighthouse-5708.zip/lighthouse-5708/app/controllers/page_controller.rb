class PageController < ActionController::Base

  def show
    render "show", :layout => "application"
  end

end
