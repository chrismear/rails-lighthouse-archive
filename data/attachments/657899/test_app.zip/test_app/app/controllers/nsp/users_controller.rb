class Nsp::UsersController < ApplicationController
  include TestMod
  
  def index
    tst_helper
  end

end
