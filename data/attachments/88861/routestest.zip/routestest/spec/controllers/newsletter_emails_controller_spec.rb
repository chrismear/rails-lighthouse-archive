require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe NewsletterEmailsController do

  integrate_views

  fixtures :newsletter_emails

  it "should get index" do
    get 'index', :locale => 'nl'
    
    response.should be_success
    response.should render_template('newsletter_emails/index')
  end

  it "should create a new newsletter_email" do
    post 'create', :locale => 'nl', :newsletter_email => {:email => 'roy@80beans.com'}
    
    assigns[:newsletter_email].should be_valid
    
    response.should be_success
    response.should render_template('newsletter_emails/create')
  end

end