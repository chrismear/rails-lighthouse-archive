require 'test_helper'

class ObjectCsHelperTest < ActionView::TestCase
end
