class CreateTables < ActiveRecord::Migration
  def self.up
    create_table :users do |t|
      t.string :name

      t.timestamps
    end
    
    create_table :roles do |t|
      t.string :description
      t.integer :level
    end
    
    create_table :user_roles do |t|
      t.integer :user_id
      t.integer :role_id
    end
    
    create_table :monkeys do |t|
      t.string :name
    end
    
    r1 = Role.create(:description => 'Guest', :level => 0)
    r2 = Role.create(:description => 'Member', :level => 1)
    r3 = Role.create(:description => 'Admin', :level => 2)
    
    u = User.create(:name => 'Peter')
    u.user_roles << UserRole.create(:role_id => r1.id)
    
#    c = ActiveRecord::Base.connection
#    c.execute("INSERT INTO roles (description,level) VALUES ('Guest',0)")
#    c.execute("INSERT INTO roles (description,level) VALUES ('Member',1)")
#    c.execute("INSERT INTO roles (description,level) VALUES ('Admin',2)")
  end

  def self.down
    drop_table :users
    drop_table :roles
    drop_table :user_roles
    drop_table :monkeys
  end
end
