class FooController < ApplicationController

  # if you comment the next line, calling http://localhost:300/foo/bar will execute code in the bar action and raise hell
  # otherwise, the foo/bar.html.erb template will b rendered
  hide_action :bar

  def bar
    raise "hell"
  end
end
