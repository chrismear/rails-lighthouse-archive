# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Bug::Application.config.secret_token = '5d9b27e5da9ed0eeb345b2a10cd352aa434ec8078d615934a0aee1b641530a49d7210af95cc81378e8ea232e8553b55538048e3722e9c11dc28c3d92908b5612'
