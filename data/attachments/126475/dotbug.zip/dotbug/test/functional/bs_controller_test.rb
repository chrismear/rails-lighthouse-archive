require 'test_helper'

class BsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:bs)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create b" do
    assert_difference('B.count') do
      post :create, :b => { }
    end

    assert_redirected_to b_path(assigns(:b))
  end

  test "should show b" do
    get :show, :id => bs(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => bs(:one).to_param
    assert_response :success
  end

  test "should update b" do
    put :update, :id => bs(:one).to_param, :b => { }
    assert_redirected_to b_path(assigns(:b))
  end

  test "should destroy b" do
    assert_difference('B.count', -1) do
      delete :destroy, :id => bs(:one).to_param
    end

    assert_redirected_to bs_path
  end
end
