class Subitem < ActiveRecord::Base
  belongs_to :item
end
