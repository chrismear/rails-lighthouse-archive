class ThingsController < ApplicationController
  rescue_from ActiveRecord::RecordNotFound, :with => :record_not_found

  def show
    @thing = Thing.find(params[:id])
  end

  private
  def record_not_found
    flash[:error] = 'That thing could not be found'
  end
end
