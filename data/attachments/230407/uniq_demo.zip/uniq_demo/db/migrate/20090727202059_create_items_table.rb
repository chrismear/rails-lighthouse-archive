class CreateItemsTable < ActiveRecord::Migration
  def self.up
    create_table :items, :id => false do |t|
      t.integer :some_id
      t.string :name
      t.timestamps
    end
    Item.create(:some_id => 1, :name => "Item 1")
    Item.create(:some_id => 2, :name => "Item 2")
  end

  def self.down
    drop_table :items
  end
end
