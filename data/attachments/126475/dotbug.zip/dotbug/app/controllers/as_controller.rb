class AsController < ApplicationController
  # GET /as
  # GET /as.xml
  def index
    @as = A.with_b_name(params[:s]).with_b_lame(params[:s]).all(:include => :b)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @as }
    end
  end

  # GET /as/1
  # GET /as/1.xml
  def show
    @a = A.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @a }
    end
  end

  # GET /as/new
  # GET /as/new.xml
  def new
    @a = A.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @a }
    end
  end

  # GET /as/1/edit
  def edit
    @a = A.find(params[:id])
  end

  # POST /as
  # POST /as.xml
  def create
    @a = A.new(params[:a])

    respond_to do |format|
      if @a.save
        flash[:notice] = 'A was successfully created.'
        format.html { redirect_to(@a) }
        format.xml  { render :xml => @a, :status => :created, :location => @a }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @a.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /as/1
  # PUT /as/1.xml
  def update
    @a = A.find(params[:id])

    respond_to do |format|
      if @a.update_attributes(params[:a])
        flash[:notice] = 'A was successfully updated.'
        format.html { redirect_to(@a) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @a.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /as/1
  # DELETE /as/1.xml
  def destroy
    @a = A.find(params[:id])
    @a.destroy

    respond_to do |format|
      format.html { redirect_to(as_url) }
      format.xml  { head :ok }
    end
  end
end
