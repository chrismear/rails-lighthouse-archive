class CreateBelongers < ActiveRecord::Migration
  def self.up
    create_table :belongers do |t|
      t.belongs_to :haver
      t.string :name
      t.timestamps
    end
  end

  def self.down
    drop_table :belongers
  end
end
