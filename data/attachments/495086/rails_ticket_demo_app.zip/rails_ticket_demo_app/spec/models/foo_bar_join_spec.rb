require 'spec_helper'

describe FooBarJoin do
  before(:each) do
    @valid_attributes = {
      :foo_id => 1,
      :bar_id => 1
    }
  end

  it "should create a new instance given valid attributes" do
    FooBarJoin.create!(@valid_attributes)
  end
  
  it "'s before_destroy callback should be called when it is called through Association's clear method" do
    foo = Foo.create
    bar = Bar.create
    foo.bars << bar
    FooBarJoin.all.count.should == 1
    #the next line should raise an error when it executes foobarjoin's before_destroy callback..
    foo.bars.clear.should raise_error(FooBarJoinBeforeDestroyCallbackIsCalled)
  end 
  
end
