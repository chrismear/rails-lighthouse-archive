require 'test_helper'

class UserTest < ActiveSupport::TestCase

  #in the console rails c test:
  #u = User.joins(:user_foo).limit(12) => ....
  #u.size => 12
  #u.size == User.joins(:user_foo).limit(12).size => false
  
  test "limit size" do
    u = User.joins(:user_foo).limit(12)
    assert_equal 12, u.size
    assert_equal 12, User.joins(:user_foo).limit(12).size
  end

  test "limit class" do
    u = User.joins(:user_foo).limit(12)
    assert_equal u.class, User.joins(:user_foo).limit(12).class
  end

  test "limited sql" do
    assert_equal 12, 
      User.find_by_sql(User.joins(:user_foo).limit(12).to_sql).size
    assert_equal User.find_by_sql(User.joins(:user_foo).limit(12).to_sql).size, 
      User.joins(:user_foo).limit(12).size
  end
end
