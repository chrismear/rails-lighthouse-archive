# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_custom-template-bug_session',
  :secret      => '3af9428d0febe105eb901d7572d5c8d9a57aab1f8fa7743a38a1ab09f2080a3d00351606ba37834a19a627e2eb50ccd98bb978799366f3042e3a41e9dedcf724'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
