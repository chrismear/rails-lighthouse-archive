require 'test_helper'

class FlaggingsHelperTest < ActionView::TestCase
end
