class ParentsController < ApplicationController
end
