class ImposterController < ApplicationController
  def new
  end
end
