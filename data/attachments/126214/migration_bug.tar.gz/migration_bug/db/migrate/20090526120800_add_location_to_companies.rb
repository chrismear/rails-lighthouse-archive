class AddLocationToCompanies < ActiveRecord::Migration
  def self.up
    add_column :companies, :location, :string
    
    Company.reset_column_information
    
    Company.all.each do |company|
      company.update_attributes(:location => 'US')
    end
  end

  def self.down
    remove_column :companies, :location
  end
end
