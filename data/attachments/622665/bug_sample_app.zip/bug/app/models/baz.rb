class Baz < ActiveRecord::Base
  belongs_to :bar
end
