# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ :name => 'Chicago' }, { :name => 'Copenhagen' }])
#   Mayor.create(:name => 'Daley', :city => cities.first)

admin = User.create(:email => "admin")
user_1 = User.create(:email => "user_1")
user_2 = User.create(:email => "user_2")
user_3 = User.create(:email => "user_3")

listing = Listing.create(:name => "Test Listing", :user_id => admin.id)

listing.comments << Comment.new(:comment => "Test1", :user_id => user_1.id)
listing.comments << Comment.new(:comment => "Test2", :user_id => user_2.id)
listing.comments << Comment.new(:comment => "Test3", :user_id => user_3.id)