require 'test_helper'

class ObjectAsHelperTest < ActionView::TestCase
end
