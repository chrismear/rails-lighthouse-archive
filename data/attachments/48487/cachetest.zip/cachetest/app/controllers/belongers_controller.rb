class BelongersController < ApplicationController
end
