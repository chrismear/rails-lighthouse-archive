class Message < ActiveRecord::Base
  
  default_scope :conditions => { :ignored => false }, :order => "rating DESC"
  named_scope :positive, :conditions => { :rating => 'positive' }
  named_scope :neutral, :conditions =>  { :rating => 'neutral' }
  named_scope :negative, :conditions => { :rating => 'negative' }
  named_scope :ignored, :conditions =>  { :ignored => true }
  
end
