class ObjectC < ActiveRecord::Base
  
	belongs_to :object_b
	has_and_belongs_to_many :object_ds
	
	accepts_nested_attributes_for :object_ds
  
end
