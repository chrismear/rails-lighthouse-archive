class Teacher < ActiveRecord::Base

  has_many :courses

end
