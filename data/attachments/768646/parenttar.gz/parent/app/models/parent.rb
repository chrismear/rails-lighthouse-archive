class Parent < ActiveRecord::Base
  attr_accessible :name, :parent_id, :state, :children_attributes
  
  has_many :children
  has_many :pending_children, :foreign_key => 'parent_id', :conditions => "state = 'pending'", :order => 'id asc', :class_name => 'Child', :dependent => :destroy

  accepts_nested_attributes_for :children, :allow_destroy => true
  accepts_nested_attributes_for :pending_children, :allow_destroy => true
end
