module LegacyDatabase
  class Foo < Base
    set_table_name :foos
    # this will attempt to connect to the DB
    # has_and_belongs_to_many :bars, :join_table => 'bars_foos'
    
    # this will work
    # has_many :bars, :through => 'foo_bars'
  end
end