class HomeController < ApplicationController
  def index
  end

  def creer
  end

  def recup-pwd
  end

end
