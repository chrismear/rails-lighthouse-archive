class ObjectAsController < ApplicationController
  
  
  
  # GET /object_as
  # GET /object_as.xml
  def index
    @object_as = ObjectA.all

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @object_as }
    end
  end

  # GET /object_as/1
  # GET /object_as/1.xml
  def show
    @object_a = ObjectA.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @object_a }
    end
  end

  # GET /object_as/new
  # GET /object_as/new.xml
  def new
    @object_a = ObjectA.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @object_a }
    end
  end

  # GET /object_as/1/edit
  def edit
    @object_a = ObjectA.find(params[:id])
  end

  # POST /object_as
  # POST /object_as.xml
  def create
    @object_a = ObjectA.new(params[:object_a])

    respond_to do |format|
      if @object_a.save
        flash[:notice] = 'ObjectA was successfully created.'
        format.html { redirect_to(@object_a) }
        format.xml  { render :xml => @object_a, :status => :created, :location => @object_a }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @object_a.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /object_as/1
  # PUT /object_as/1.xml
  def update
    @object_a = ObjectA.find(params[:id])

    respond_to do |format|
      if @object_a.update_attributes(params[:object_a])
        flash[:notice] = 'ObjectA was successfully updated.'
        format.html { redirect_to(@object_a) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @object_a.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /object_as/1
  # DELETE /object_as/1.xml
  def destroy
    @object_a = ObjectA.find(params[:id])
    @object_a.destroy

    respond_to do |format|
      format.html { redirect_to(object_as_url) }
      format.xml  { head :ok }
    end
  end
end
