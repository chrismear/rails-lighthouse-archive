class Belonger < ActiveRecord::Base
  belongs_to :haver
end
