# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SApp::Application.config.secret_token = '635c15f83a3f56c63f0dc356114de0432d7e29fd8d602c53649eec860ac30372fc694778488f6058e6de91c834a018ca0fc1f68535abbe5ace36ccd00f02c0b9'
