class CustomPost < ActiveRecord::Base
end
