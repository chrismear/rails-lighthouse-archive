class CreateMultiSaves < ActiveRecord::Migration
  def self.up
    create_table :multi_saves do |t|
    	t.integer :id_dependant
    	t.string :name
    	t.string :name_dependant
      t.timestamps
    end
  end

  def self.down
    drop_table :multi_saves
  end
end
