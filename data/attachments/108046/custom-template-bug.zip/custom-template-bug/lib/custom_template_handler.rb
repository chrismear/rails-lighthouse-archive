class CustomTemplateHandler < ActionView::TemplateHandler
  
  def render(template, assigns) 
    "it works"
  end 
  
  
end