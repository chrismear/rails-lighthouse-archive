class ObjectA < ActiveRecord::Base
  
  belongs_to :object_d
	has_many :object_bs

  accepts_nested_attributes_for :object_bs
  accepts_nested_attributes_for :object_d
  
end
