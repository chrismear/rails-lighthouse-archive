class TabsController < ApplicationController
end
