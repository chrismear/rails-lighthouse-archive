class Customer < ActiveRecord::Base
  has_many :invoices, :primary_key => :customer_alternate_key, :foreign_key => :customer_foreign_key
  has_many :line_items, :through => :invoices
end
