class MultiSave < ActiveRecord::Base
	
	after_save :overwrite_id_dependant
	
	def overwrite_id_dependant
		write_attribute(:id_dependant, id * 5)
	end
	
	def name=(value)
		write_attribute :name, value
		write_attribute :name_dependant, value + " rocks"
	end
end
