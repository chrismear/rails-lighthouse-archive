require 'test_helper'

class XmlCachingHelperTest < ActionView::TestCase
end
