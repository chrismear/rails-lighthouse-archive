module LegacyDatabase
  class Baz < Base
    set_table_name :bazs
    
    # this will attempt to connect to the DB
    scope :active, where(:active => true)
  end
end