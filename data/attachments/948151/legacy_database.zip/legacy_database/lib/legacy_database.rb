# There are 3 scenarios listed in terms of importance.
# 
# 1. scope calls will attempt to connect to the database before a 
#    connection has been established
# 
# 2. has_and_belong_to_many associations in the models will attempt to
#    connect to the database before a connection has been established
# 
# 3. an establish_connection in the Base class as shown below will
#    not work regardless of database.yml settings. Although, setting
#    a gem up this way is probably not useful anyway ;)
# 
# Instructions:
# 
# 1. Include this gem in your rails 3 app's Gemfile
# gem 'legacy_database', :path => '/path/to/legacy_database'
# 2. bundle install the gem
# 
# 
# Scenario 1
# 1) comment out the habtm lines in foo.rb and bar.rb
# 2) ensure the scope line in baz.rb is not commented out
# 3) attempt to load the console
# 
# Scenario 2
# 1) comment out scope in baz.rb
# 2) Ensure the habtm lines in bar.rb and foo.rb are not commented out
# 3) attempt to load the console
# 
# Scenario 3
# 1) uncomment the 'establish_connection' line in this file and attempt
# to load a console
# 2) add a legacdy_database config to your database.yml and load the console

module LegacyDatabase
  class Base < ActiveRecord::Base
    # If the following link is uncommented a Rails 3 app will not load as you 
    # will get a adapter not configured error, even if your database.yml
    # has that database configured in it

    # establish_connection 'legacy_database'
  end
end

Dir[File.dirname(__FILE__) + "/../lib/legacy_database/*.rb"].each {|f| require f} 
