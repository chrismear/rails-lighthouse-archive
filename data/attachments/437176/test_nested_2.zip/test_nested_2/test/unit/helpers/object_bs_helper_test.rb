require 'test_helper'

class ObjectBsHelperTest < ActionView::TestCase
end
