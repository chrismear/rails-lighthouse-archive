require File.join(File.dirname(__FILE__), 'boot')
Rails::Initializer.run
