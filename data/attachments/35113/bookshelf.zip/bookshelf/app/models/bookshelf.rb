class Bookshelf < ActiveRecord::Base
   has_many :books
end
