class FooBarJoin < ActiveRecord::Base

  belongs_to :foo
  belongs_to :bar
  
  before_destroy :i_am_called
  
  def i_am_called
    raise FooBarJoinBeforeDestroyCallbackIsCalled
  end
  
end

class FooBarJoinBeforeDestroyCallbackIsCalled < StandardError 
end