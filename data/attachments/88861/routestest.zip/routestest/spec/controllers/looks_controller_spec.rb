require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe LooksController do

  integrate_views

  fixtures :looks, :look_categories, :products, :product_translations

  it "should get index" do
    get 'index', :locale => 'nl'
    
    assigns[:looks].should have(1).item
    
    response.should be_success
    response.should render_template('looks/index')
  end

  it "should get show" do
    get 'show', :locale => 'nl', :id => looks(:look_one)
    
    assigns[:look].should == looks(:look_one)
    assigns[:look].products.should_not be_empty
    assigns[:looks].should_not be_nil
    
    response.should be_success
    response.should render_template('looks/show')
  end

end