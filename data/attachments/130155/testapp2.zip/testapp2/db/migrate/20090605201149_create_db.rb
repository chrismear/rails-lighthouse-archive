class CreateDb < ActiveRecord::Migration
  def self.up
    create_table "bars", :force => true do |t|
      t.string  "name"
      t.datetime "created_at"
      t.datetime "updated_at"
    end

    create_table "linkages", :force => true do |t|
      t.integer "foo_id"
      t.integer "thing_id"
      t.string  "thing_type"
      t.datetime "created_at"
      t.datetime "updated_at"
    end

    create_table "foos", :force => true do |t|
      t.string  "name"
      t.datetime "created_at"
      t.datetime "updated_at"
    end
  end

  def self.down
  end
end
