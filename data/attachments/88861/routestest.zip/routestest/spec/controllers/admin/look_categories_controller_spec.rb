require File.expand_path(File.dirname(__FILE__) + '/../../spec_helper')

describe Admin::LookCategoriesController do

  integrate_views

  fixtures :look_categories

  it "should get index" do
    get 'index'
    
    assigns[:look_categories].should_not be_nil
    
    response.should be_success
    response.should render_template('admin/look_categories/index')
  end

  it "should get new" do
    get 'new'
    
    assigns[:look_category].should_not be_nil
    
    response.should be_success
    response.should render_template('admin/look_categories/new')
  end

  it "should create a new look_category with valid params" do
    post 'create', :look_category => {:name => 'new'}
    
    assigns[:look_category].should be_valid
  end

  it "should not create a new look_category with invalid params" do
    post 'create', :look_category => {:name => ''}
    
    assigns[:look_category].should_not be_valid
    
    response.should be_success
    response.should render_template('admin/look_categories/create.js.rjs')
  end

  it "should get edit for an existing look_category" do
    get 'edit', :id => look_categories(:casual)
    
    assigns[:look_category].should_not be_nil
    
    response.should be_success
    response.should render_template('admin/look_categories/edit')
  end

  it "should update a look_category with valid params" do
    put 'update', :id => look_categories(:casual).id, :look_category => {:name => 'new'}
    
    assigns[:look_category].should be_valid
    
    response.should be_success
    response.should render_template('admin/look_categories/update.js.rjs')
  end

  it "should not update look_category with invalid params" do
    post 'update', :id => look_categories(:casual).id, :look_category => {:name => ''}
    
    assigns[:look_category].should_not be_valid
    assigns[:look_category].should have(1).error_on(:name)
    
    response.should be_success
    response.should render_template('admin/look_categories/update.js.rjs')
  end

end