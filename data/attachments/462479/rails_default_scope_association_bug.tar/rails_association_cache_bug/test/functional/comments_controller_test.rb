require File.dirname(__FILE__) + '/../test_helper.rb'

class CommentsControllerTest < ActionController::TestCase
  def setup 
    activate_authlogic
    @listing = listings(:owner_listing)
  end
  
  def test_create_comment_with_user
    login_as(:user)
    assert_difference "Comment.count", 1 do
      xhr :post, :create, :id => @listing.id, :comment => {:comment => "Test"}
    end
    assert assigns(:listing)
    assert assigns(:comment)
    assert assigns(:success)
    assert assigns(:listing).comments.include? assigns(:comment)
  end
  
  def test_cannot_create_comment_without_user
    assert_no_difference "Comment.count" do
      xhr :post, :create, :id => @listing.id, :comment => {:comment => "Test"}
    end
  end
  
  def test_can_destroy_own_comment
    login_as(:user)
    assert_difference "Comment.count", -1 do
      xhr :delete, :destroy, :id => comments(:user_comment)
    end
  end
  
  def test_cannot_destroy_other_comment
    login_as(:user)
    assert_no_difference "Comment.count" do
      xhr :delete, :destroy, :id => comments(:owner_comment)
    end
  end
  
  def test_moderator_can_destroy_other_comments
    login_as(:moderator)
    assert_difference "Comment.count", -1 do
      xhr :delete, :destroy, :id => comments(:user_comment)
    end
  end
end
