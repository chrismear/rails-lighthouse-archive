class Paper < ActiveRecord::Base
end
