# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Segfaulter::Application.config.secret_token = '96cb0e5a1db67070035d73f9908112ee534f08476eb09d6ec737d0dd67244d4a3fddc93493e194cd11de0c63c1e9f83d5c4b80a94cb5eea79928611de7863ef2'
