class ContactsController < ApplicationController

  def foo; end

  def bar; end

end
