# 
# To change this template, choose Tools | Templates
# and open the template in the editor.
 

class AccountAssociation < ActiveRecord::Base
  belongs_to :account
end
