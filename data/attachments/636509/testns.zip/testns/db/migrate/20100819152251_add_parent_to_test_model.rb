class AddParentToTestModel < ActiveRecord::Migration
  def self.up
    add_column :test_models, :parent_model_id, :integer
  end

  def self.down
    remove_column :test_models, :parent_model_id
  end
end
