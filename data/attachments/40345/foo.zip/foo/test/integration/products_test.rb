require File.dirname(__FILE__) + '/../test_helper'
require "ruby-debug"


class ProductsTest < ActionController::IntegrationTest
  # fixtures :your, :models

  def test_access_products_list
    get "products"
    assert_response 401
    get "products", nil, :authorization => ActionController::HttpAuthentication::Basic.encode_credentials("enrico", "teotti")    
    assert_response :success    
  end
  
  def test_create_product
    post "products"
    assert_response 401
    post "products", {:product => {:name => "banana"}}, :authorization => ActionController::HttpAuthentication::Basic.encode_credentials("enrico", "teotti")
    assert_response :redirect
    follow_redirect!
    assert_response :success
    assert_template "products/show"  
  end

  def test_redirect_without_authentication
    get "dummy_redirect/one"
    assert_response :redirect
    follow_redirect!
    assert_response :success
    assert_template "dummy_redirect/two"
  end
end
