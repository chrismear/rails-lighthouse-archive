require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe SessionsController do

  integrate_views

  fixtures :customers

  before do
    @customer = customers(:customer_one)
  end

  it "should get new" do
    get 'new', :locale => 'nl'
    
    response.should be_success
    response.should render_template('sessions/new')
  end

  it "should create a session with valid password" do
    post 'create', :locale => 'nl', :email => @customer.email, :password => 'password'
    
    session[:current_customer_id].should == @customer.id
    
    response.should be_success
    response.should render_template('sessions/create')
  end

  it "should create a session with valid password and redirect to cart" do
    post 'create', :locale => 'nl', :email => @customer.email, :password => 'password', :redirect_to_cart => true
    
    session[:current_customer_id].should == @customer.id
    
    response.should be_success
    response.should render_template('sessions/create')
  end

  it "should not create a session with invalid password" do
    post 'create', :locale => 'nl', :email => @customer.email, :password => 'nonsense'
    
    session[:current_customer_id].should be_nil
    
    response.should be_success
    response.should render_template('sessions/create')
  end

  it "should not create session for inactive clients" do
    @customer.update_attribute(:active, false)
    
    post 'create', :locale => 'nl', :email => @customer.email, :password => 'password'
    
    session[:current_customer_id].should_not be_nil
    
    response.should be_success
    response.should render_template('sessions/create')
  end

  it "should destroy a session" do
    login
    
    delete 'destroy', :locale => 'nl'
    
    session[:current_customer_id].should be_nil
    
    response.should be_success
    response.should render_template('sessions/destroy')
  end

end