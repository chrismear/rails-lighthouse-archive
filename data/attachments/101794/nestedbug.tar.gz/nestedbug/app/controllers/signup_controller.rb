class SignupController < ApplicationController

  def index
  end
  
  def new
    @order = Order.new
    @account = @order.account = Account.new
    @account.user = User.new
    @account.contact_info = ContactInfo.new
  end
  
  def create
    @order = Order.new(params[:order])
    
    @order.transaction do
      @order.save!
    end
    
    render :text => 'success!'
  rescue
    # BUG: when the transaction raises and exception and puts us here
    # @order.account.contact_info.id will not be nil. This will then
    # render the form with an id attribute for contact_info, which
    # when submitted will screw up creating @order and return the error:
    # -------------------------------------------------------------------
    #      You have a nil object when you didn't expect it!
    #      You might have expected an instance of ActiveRecord::Base.
    #      The error occurred while evaluating nil.new_record?
    # -------------------------------------------------------------------
    # The solution is to make sure after a rollback that EVERY "id"
    # attribute is nil'ed
    
    render :new
  end

  def show
  end
  
end
