require 'test_helper'

class ChildrenHelperTest < ActionView::TestCase
end
