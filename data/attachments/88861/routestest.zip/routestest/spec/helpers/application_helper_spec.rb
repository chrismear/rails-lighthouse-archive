require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe ApplicationHelper do

  it "should return the current BeansShop configuration" do
    helper.shop_config.should == BeansShop::Configuration.current
  end

  it "should format currency with an nl locale and euro currency" do
    helper.stub!(:currency).and_return('euro')
    
    I18n.locale = 'nl'
    
    helper.format_currency(100.91).should == '€ 100,91'
    helper.format_currency(1000.91).should == '€ 1.000,91'
    helper.format_currency(100).should == '€ 100,-'
    helper.format_currency(100.00).should == '€ 100,-'
    helper.format_currency(nil).should be_nil
    helper.format_currency('').should be_nil
  end

  it "should format currency with an en locale and usd currency" do
    helper.stub!(:currency).and_return('usd')
    
    I18n.locale = 'en'
    
    helper.format_currency(100.91).should == '$ 100.91'
    helper.format_currency(1000.91).should == '$ 1,000.91'
    helper.format_currency(100).should == '$ 100.-'
    helper.format_currency(100.00).should == '$ 100.-'
    helper.format_currency(nil).should be_nil
    helper.format_currency('').should be_nil
  end

  it "should format currency with an overridden currency" do
    I18n.locale = 'en'
    
    helper.format_currency(100.91, 'usd').should == '$ 100.91'
  end

end