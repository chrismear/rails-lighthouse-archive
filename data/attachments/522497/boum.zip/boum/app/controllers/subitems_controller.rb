class SubitemsController < ApplicationController
  def index
    @subitems = Item.first.subitems
  end
end
