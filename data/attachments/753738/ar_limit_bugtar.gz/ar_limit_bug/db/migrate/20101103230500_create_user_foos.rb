class CreateUserFoos < ActiveRecord::Migration
  def self.up
    create_table :user_foos do |t|
      t.references :user
      t.string :foo

      t.timestamps
    end
  end

  def self.down
    drop_table :user_foos
  end
end
