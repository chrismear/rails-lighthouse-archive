class Bar < ActiveRecord::Base
end
