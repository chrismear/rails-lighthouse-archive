require 'test_helper'

class ThirdPartyExtensionHelperTest < ActionView::TestCase
end
