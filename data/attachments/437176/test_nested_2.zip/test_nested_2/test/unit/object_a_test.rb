require 'test_helper'

class ObjectATest < ActiveSupport::TestCase
  # Replace this with your real tests.
  test "saving nested object_a" do
    objectA1 = ObjectA.new()
    objectB1 = ObjectB.new()
 
    objectA1.object_bs << objectB1
    
    objectC1 = ObjectC.new()    
    objectC2 = ObjectC.new()

    objectD1 = ObjectD.new()
    objectD2 = ObjectD.new()

    objectC1.object_ds << objectD1 << objectD2    
    objectC2.object_ds << objectD1 << objectD2

    objectB1.object_cs << objectC1 << objectC2
    objectA1.object_d = objectD1

    objectA1.save 
  end
end
