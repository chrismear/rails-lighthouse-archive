class CreateAs < ActiveRecord::Migration
  def self.up
    create_table :as do |t|
      t.string :name
      t.references :b

      t.timestamps
    end
  end

  def self.down
    drop_table :as
  end
end
