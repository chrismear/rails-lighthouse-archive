require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe ProductsController do

  integrate_views

  fixtures :categories, :products, :product_translations, :product_images, :product_collections, :product_variations

  it "should show a list of products" do
    get 'index', :locale => 'nl', :category_id => categories(:dresses)
    
    assigns[:category].should == categories(:dresses)
    assigns[:products].should_not be_nil
    
    response.should be_success
    response.should render_template('products/index')
  end

  it "should show a product page with a product collection" do
    get 'show', :locale => 'nl', :category_id => categories(:dresses), :id => products(:dress_1)
    
    assigns[:category].should == categories(:dresses)
    assigns[:product].should == products(:dress_1)
    assigns[:product_collections].should include(product_collections(:collection_one))
    
    response.should be_success
    response.should render_template('products/show')
  end

  it "should show a product page without images" do
    ProductImage.delete_all
    
    get 'show', :locale => 'nl', :category_id => categories(:dresses), :id => products(:dress_1)
    
    assigns[:category].should == categories(:dresses)
    assigns[:product].should == products(:dress_1)
    
    response.should be_success
    response.should render_template('products/show')
  end

  it "should show a product page without images and variations" do
    ProductImage.delete_all
    ProductVariation.delete_all
    
    get 'show', :locale => 'nl', :category_id => categories(:dresses), :id => products(:dress_1)
    
    assigns[:category].should == categories(:dresses)
    assigns[:product].should == products(:dress_1)
    
    response.should be_success
    response.should render_template('products/show')
  end

  it "should show a product page without a product collection" do
    get 'show', :locale => 'nl', :category_id => categories(:dresses), :id => products(:dress_4_empty)
    
    assigns[:product_collections].should be_empty
    
    response.should be_success
    response.should render_template('products/show')
  end

  it "should show a product page without a price" do
    products(:dress_4_empty).update_attributes!(:price => nil)
    
    get 'show', :locale => 'nl', :category_id => categories(:dresses), :id => products(:dress_4_empty)
    
    response.should be_success
    response.should render_template('products/show')
  end

end