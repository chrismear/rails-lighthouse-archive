class Group < ActiveRecord::Base
has_many :UserGroups
has_many :Users, :through=>:UserGroups
end
