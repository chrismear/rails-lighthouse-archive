class AddSslFlag < ActiveRecord::Migration
  def self.up
    puts "Migrating"
  end

  def self.down
  end
end
