class TestController < ApplicationController
  def index
  end

  def login
  end

  def private
  end

end
