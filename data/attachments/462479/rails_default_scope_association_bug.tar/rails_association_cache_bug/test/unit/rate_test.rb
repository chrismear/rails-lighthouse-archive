require File.dirname(__FILE__) + '/../test_helper.rb'

class RateTest < ActiveSupport::TestCase
end
