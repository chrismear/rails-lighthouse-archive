class ApplicationController < ActionController::Base

  helper :all

end