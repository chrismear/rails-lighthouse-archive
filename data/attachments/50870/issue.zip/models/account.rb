# 
# To change this template, choose Tools | Templates
# and open the template in the editor.
 

class Account < ActiveRecord::Base
  has_many :associations, :class_name => 'AccountAssociation'
  has_one :owning_association, :class_name => 'AccountAssociation', :conditions => "association_type = 'OWNER'"
end
