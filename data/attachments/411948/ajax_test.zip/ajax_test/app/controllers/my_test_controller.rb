class MyTestController < ApplicationController
  def index
    if [:post,:put].include? request.method
      p params
    end
  end

  def switch
    p "switch..."
    render :update do |page|
      p "switched"
      page.replace_html 'alternate', :partial => "ajax_form"
    end
  end

  def handle_ajax_button
    p params
    render :update do |page|
      page.replace_html 'alternate', ''
    end
  end

end
