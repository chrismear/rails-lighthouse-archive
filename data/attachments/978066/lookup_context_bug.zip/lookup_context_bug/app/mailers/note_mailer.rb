class NoteMailer < ActionMailer::Base
  default :from => "from@example.com"

  def foo
    @notes = []
    render_to_string(:template => "notes/index.html.erb") # <-- Removing this line makes the test pass
    # self.instance_variable_set(:@lookup_context, nil) # <-- So does enabling this
    mail(:to => "example@example.com")
  end
end
