require 'test_helper'

class Nsp::UsersHelperTest < ActionView::TestCase
end
