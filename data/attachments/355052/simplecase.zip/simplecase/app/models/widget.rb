class Widget < ActiveRecord::Base
  belongs_to :bar
end
