class Emailer < ActionMailer::Base

  def general()
  	@subject    = "This is a test email"
    @body  = {:message => "To test action_mailer in Rails 2.3.2"}
    @recipients = 'foo@foo.com'
    @from       = 'foo@foo.com'
    @sent_on    = Time.now
    @headers    = {}
  end

end
