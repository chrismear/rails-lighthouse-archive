require File.dirname(__FILE__) + '/../test_helper.rb'

class ListingsControllerTest < ActionController::TestCase
    
  setup do
    activate_authlogic
    @listing = listings(:owner_listing)
  end
  
  def test_should_get_index
    get :index
    assert_response :success
    assert assigns(:listings)
  end
  
  def test_should_not_get_new_without_user
    get :new
    assert_redirected_to root_path
    
    login_as(:user)
    get :new
    assert_redirected_to root_path
  end

  def test_should_not_create_listing_user
    login_as(:user)
    assert_no_difference 'Listing.count' do
      post :create, :listing => @listing.attributes
    end
    assert_redirected_to root_url
  end
  
  def test_should_create_listing_admin
    login_as(:admin)
    assert_difference 'Listing.count', 1 do
      post :create, :listing => @listing.attributes
    end
    assert assigns(:listing).additional_information
    assert_redirected_to listing_path(assigns(:listing))
  end

  def test_should_show_listing
    get :show, :id => @listing.id
    assert_response :success, @response.body
  end

  def test_should_get_edit_if_owner
    login_as(:owner)
    get :edit, :id => @listing.id
    assert_response :success, @response.body
  end
  
  def test_should_not_get_edit_if_wrong_user
    login_as(:user)
    get :edit, :id => @listing.id
    assert_redirected_to root_path
  end
  
  def test_should_update_listing_if_owner
    login_as(:owner)
    put :update, :id => @listing.id, :listing => @listing.attributes
    assert_redirected_to listing_path(assigns(:listing))
  end
  
  def test_should_not_update_listing_if_wrong_user
    login_as(:user)
    put :update, :id => @listing.id, :listing => @listing.attributes
    assert_redirected_to root_url
  end
  
  def test_should_destroy_listing_if_owner
    login_as(:owner)
    assert_difference "Listing.count", -1 do
      delete :destroy, :id => @listing.id
    end
    assert_redirected_to listings_url
  end
  
  def test_should_not_destroy_listing_if_wrong_user
    login_as(:user)
    assert_no_difference "Listing.count" do
      delete :destroy, :id => @listing.id
    end
    assert_redirected_to root_url
  end
  
  def test_should_rate_if_user
    login_as(:user)
    assert_difference "Rate.count", 1 do
      xhr :post, :rate, :id => @listing.id, :stars => 2, :dimension => 'greens'
    end
  end
  
  def test_should_not_rate_if_no_user
    assert_no_difference "Rate.count" do
      xhr :post, :rate, :id => @listing.id, :stars => 2, :dimension => 'greens'
    end
  end
end
