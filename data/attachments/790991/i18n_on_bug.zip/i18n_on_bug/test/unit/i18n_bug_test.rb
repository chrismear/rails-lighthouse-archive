require 'test_helper'

class I18nBugTest < ActiveSupport::TestCase

  def setup
    puts I18n.t('bug').inspect
  end

  def test_at_key_should_return_translation
    assert_equal 'at at', I18n.t('bug.at')
  end

  def test_on_key_should_return_translation
    assert_equal 'on on', I18n.t('bug.on')
  end

end