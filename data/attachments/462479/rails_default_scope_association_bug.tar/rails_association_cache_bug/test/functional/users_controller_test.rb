require File.dirname(__FILE__) + '/../test_helper.rb'

class UsersControllerTest < ActionController::TestCase
  setup :activate_authlogic

  def test_should_view_create_page
    get :new
    assert assigns(:user)
    assert_response :success
  end

  def test_should_not_view_create_page_when_logged_in
    UserSession.create(users(:user))
    get :new
    assert_redirected_to root_path
  end

  def test_should_create_user
    assert_difference "User.count", 1 do
      create_user(:email => "new_user@example.com", :login => "new_login")
    end
    assert flash[:notice]
    assert assigns(:user)
    assert assigns(:user).user?
    assert_redirected_to user_path(assigns(:user))
  end
  
  def test_should_not_create_user
    assert_no_difference "User.count" do
      create_user
    end
    assert_nil flash[:notice]
    assert_equal assigns(:user).errors[:email], ["has already been taken"]
    assert assigns(:user)
    assert assigns(:user).new_record?
    assert_template :new
  end
  
  def test_should_edit_own_account
    login_as(:user)
    get :edit
    assert_response :success
  end
  
  def test_should_not_goto_edit_page
    get :edit
    assert_redirected_to root_url
  end
  
  def test_should_edit_own_account_always
    login_as(:user)
    get :edit, :id => users(:owner).id
    assert_redirected_to root_url
  end
  
  def test_should_update_account
    login_as(:user)
    post :update, :id => users(:user).id, :user => {:email => 'new_email@example.com'}
    assert_response :success
    assert assigns(:user)
    assert_equal assigns(:user).email, 'new_email@example.com'
  end
  
  private
  
  def create_user(options = {})
    post :create, :user => {:email => 'user@example.com', :login => "user", :password => 'password', :password_confirmation => 'password'}.merge(options)
  end
end
