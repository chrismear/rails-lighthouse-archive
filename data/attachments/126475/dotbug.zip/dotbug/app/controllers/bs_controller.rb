class BsController < ApplicationController
  # GET /bs
  # GET /bs.xml
  def index
    @bs = B.all

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @bs }
    end
  end

  # GET /bs/1
  # GET /bs/1.xml
  def show
    @b = B.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @b }
    end
  end

  # GET /bs/new
  # GET /bs/new.xml
  def new
    @b = B.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @b }
    end
  end

  # GET /bs/1/edit
  def edit
    @b = B.find(params[:id])
  end

  # POST /bs
  # POST /bs.xml
  def create
    @b = B.new(params[:b])

    respond_to do |format|
      if @b.save
        flash[:notice] = 'B was successfully created.'
        format.html { redirect_to(@b) }
        format.xml  { render :xml => @b, :status => :created, :location => @b }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @b.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /bs/1
  # PUT /bs/1.xml
  def update
    @b = B.find(params[:id])

    respond_to do |format|
      if @b.update_attributes(params[:b])
        flash[:notice] = 'B was successfully updated.'
        format.html { redirect_to(@b) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @b.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /bs/1
  # DELETE /bs/1.xml
  def destroy
    @b = B.find(params[:id])
    @b.destroy

    respond_to do |format|
      format.html { redirect_to(bs_url) }
      format.xml  { head :ok }
    end
  end
end
