class ApplicationController < ActionController::Base
  protect_from_forgery
  layout 'application'

  before_filter :set_message

  def set_message
    @message = "I am set"
  end

end
