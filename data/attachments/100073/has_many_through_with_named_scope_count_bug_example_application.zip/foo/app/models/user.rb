class User < ActiveRecord::Base

  has_many :community_memberships
  has_many :communities, :through => :community_memberships

end
