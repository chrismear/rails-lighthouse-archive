module ApplicationHelper
  def break_page
    »
  end
end
