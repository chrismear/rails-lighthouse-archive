# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '53f5ade79ea237347350e1f089f5fd5db49d48bec2a7318c32dc6ecf94d5dde053ab6f9288f49025e22719c5a6b8533aa0d632cbb4c71ad7af21b15ba3bd64e6';
