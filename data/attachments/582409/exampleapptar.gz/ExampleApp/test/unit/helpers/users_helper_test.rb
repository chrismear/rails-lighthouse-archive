require 'test_helper'

class UsersHelperTest < ActionView::TestCase
end
