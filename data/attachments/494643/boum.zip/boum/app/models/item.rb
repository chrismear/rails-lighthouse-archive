class Item < ActiveRecord::Base
  has_many :subitems
end
