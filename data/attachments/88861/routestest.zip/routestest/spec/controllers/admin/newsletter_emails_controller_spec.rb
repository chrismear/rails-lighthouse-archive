require File.expand_path(File.dirname(__FILE__) + '/../../spec_helper')

describe Admin::NewsletterEmailsController do

  integrate_views

  fixtures :newsletter_emails

  it "should get index" do
    get 'index', :locale => 'nl'

    assigns[:newsletter_emails].should include(newsletter_emails(:ron))
    assigns[:newsletter_emails].should include(newsletter_emails(:thijs))
    
    response.should be_success
    response.should render_template('admin/newsletter_emails/index')
  end

  it "should destroy a newsletter_email" do
    lambda {
      delete 'destroy', :id => newsletter_emails(:ron)
    }.should change(NewsletterEmail, :count).by(-1)
    
    response.should be_success
    response.should render_template('admin/newsletter_emails/destroy')
  end

end
