require 'test_helper'

class PostTest < ActiveSupport::TestCase
  test "save should be true" do
    post = Post.new :title => "Foo"
    assert post.save, "Post save should be true"
  end

  test "save! should be true" do
    post = Post.new :title => "Foo"
    assert post.save!, "Post save should be true"
  end

  test "save! should change the number of records" do
    assert_difference('Post.count', 1) do
      Post.create! :title => "Foo"
    end
  end

  test "save assigns the id" do
    post = Post.create! :title => "Foo"
    assert post.id.present?, "Post should have an id"
  end
end
