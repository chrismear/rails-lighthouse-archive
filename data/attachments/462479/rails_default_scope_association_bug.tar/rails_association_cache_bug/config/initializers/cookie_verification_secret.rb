# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.cookie_secret = '5d9c9b2fe24ce7bb578548c2549c797abe98bf3ceadf473388aefff1ccf526304f36fc9af672bcaf9672d16a028255002bde4f57b444633ebdd6f50fa75205da'
