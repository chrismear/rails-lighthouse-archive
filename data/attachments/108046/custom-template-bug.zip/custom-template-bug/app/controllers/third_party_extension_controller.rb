class ThirdPartyExtensionController < ApplicationController

  def template_with_empty_action
  end

  def template_with_render_template
    render :template => "third_party_extension/template_with_render_template"
  end

  def template_with_render_template_with_extension
    render :template => "third_party_extension/template_with_render_template_with_extension.custom"
  end

end
