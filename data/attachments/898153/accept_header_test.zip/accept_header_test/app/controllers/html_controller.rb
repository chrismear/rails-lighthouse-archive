class HtmlController < ApplicationController
  def index
  end

  def post
    
  end

end
