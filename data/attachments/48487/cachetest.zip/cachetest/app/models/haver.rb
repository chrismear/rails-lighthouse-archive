class Haver < ActiveRecord::Base
  has_many :belongers
end
