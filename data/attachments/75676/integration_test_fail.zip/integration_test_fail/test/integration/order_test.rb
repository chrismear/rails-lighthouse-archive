require 'test_helper'

class OrderTest < ActionController::IntegrationTest

  def test_orde_add_to_cart
    20.times do
      put "/orders/#{products(:one).id}/add_to_cart"
    end
  end

end
