require 'test_helper'

class ObjectCsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:object_cs)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create object_c" do
    assert_difference('ObjectC.count') do
      post :create, :object_c => { }
    end

    assert_redirected_to object_c_path(assigns(:object_c))
  end

  test "should show object_c" do
    get :show, :id => object_cs(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => object_cs(:one).to_param
    assert_response :success
  end

  test "should update object_c" do
    put :update, :id => object_cs(:one).to_param, :object_c => { }
    assert_redirected_to object_c_path(assigns(:object_c))
  end

  test "should destroy object_c" do
    assert_difference('ObjectC.count', -1) do
      delete :destroy, :id => object_cs(:one).to_param
    end

    assert_redirected_to object_cs_path
  end
end
