class CreateExpenseReimbursements < ActiveRecord::Migration
  def self.up
    create_table :expense_reimbursements do |t|
      t.string :name
      t.integer :expense_id
      t.timestamps
    end
  end

  def self.down
    drop_table :expense_reimbursements
  end
end
