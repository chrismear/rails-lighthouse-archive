class ParentModel < ActiveRecord::Base
  has_many :test_models
  
end
