require 'test_helper'

class TabsHelperTest < ActionView::TestCase
end
