# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '93c4f5fa5c44b01a4d80f4524ab3b751412ff47332e589eaf725662ef864a38ac624b3106d1594a06b81ac3ad6b7d091f52186f6987b3bd917ec44be442855ff'
