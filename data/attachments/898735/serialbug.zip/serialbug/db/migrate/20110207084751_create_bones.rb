class CreateBones < ActiveRecord::Migration
  def self.up
    create_table :bones do |t|
      t.string  :type
      t.integer :size
      t.timestamps
    end
  end

  def self.down
    drop_table :bones
  end
end
