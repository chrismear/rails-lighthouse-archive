require 'test_helper'

class SignUpHelperTest < ActionView::TestCase
end
