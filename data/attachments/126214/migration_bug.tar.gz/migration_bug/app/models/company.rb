class Company < ActiveRecord::Base
  class Firm < Company
    validates_presence_of :description
  end
end
