class Book < ActiveRecord::Base
   belongs_to :bookshelf
end
