class CreateFooBarJoins < ActiveRecord::Migration
  def self.up
    create_table :foo_bar_joins do |t|
      t.integer :foo_id
      t.integer :bar_id

      t.timestamps
    end
  end

  def self.down
    drop_table :foo_bar_joins
  end
end
