require File.dirname(__FILE__) + '/../test_helper.rb'

class UserTest < ActiveSupport::TestCase
  def test_admin
    assert users(:admin).admin?
    assert_equal users(:admin).flags, 1
  end
  
  def test_moderator
    assert users(:moderator).moderator?
    assert_equal users(:moderator).flags, 2
  end
  
  def test_user
    assert users(:user).user?
    assert_equal users(:user).flags, 4
  end
  
  def test_owner
    assert users(:owner).owner?
    assert_equal users(:owner).flags, 8
  end
  
  def test_has_listings
    assert users(:user).listings
  end
  
  def test_has_comments
    assert users(:user).comments
  end
  
  def test_has_flaggings
    assert users(:user).flaggings
  end
end
