# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ErrorApp::Application.config.secret_token = 'ea100d5567b400280b278310e47bc4fafc7edd259b4fa8f9322b7ede2bc1aa991eb43286cae42f81414d3c2f55d21e92726eb5fdec33aa7608519b0370110826'
