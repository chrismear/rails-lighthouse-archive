require 'test_helper'

class UserTest < ActiveSupport::TestCase
    
	def setup
		u = User.new
		u.save
	end
  
  test "check if user preference completely deserialized" do
  	user = User.last
  	assert(user.preferences.test.kind_of?(Something), 'class of attr test is: ' + user.preferences.test.class.to_s)
  end
  
  
  
end
