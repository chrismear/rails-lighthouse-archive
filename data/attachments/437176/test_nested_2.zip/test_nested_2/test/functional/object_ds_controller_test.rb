require 'test_helper'

class ObjectDsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:object_ds)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create object_d" do
    assert_difference('ObjectD.count') do
      post :create, :object_d => { }
    end

    assert_redirected_to object_d_path(assigns(:object_d))
  end

  test "should show object_d" do
    get :show, :id => object_ds(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => object_ds(:one).to_param
    assert_response :success
  end

  test "should update object_d" do
    put :update, :id => object_ds(:one).to_param, :object_d => { }
    assert_redirected_to object_d_path(assigns(:object_d))
  end

  test "should destroy object_d" do
    assert_difference('ObjectD.count', -1) do
      delete :destroy, :id => object_ds(:one).to_param
    end

    assert_redirected_to object_ds_path
  end
end
