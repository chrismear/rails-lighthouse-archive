require 'test_helper'

class PostTest < ActiveSupport::TestCase
  # Replace this with your real tests.

	def test_storage_change
	    post = Post.create!
	    comment = Comment.create!( :post => Post.create! )
	    post.comments << comment
	    assert_equal post.id, comment.post.id
	    assert_equal post.id, comment.post_id
	end
	
	def test_storage_change_with_reload
    post = Post.create!
    comment = Comment.create!( :post => Post.create! )
    
    comment.reload

    post.comments << comment
    assert_equal post.id, comment.post.id
    assert_equal post.id, comment.post_id  
  end

end
