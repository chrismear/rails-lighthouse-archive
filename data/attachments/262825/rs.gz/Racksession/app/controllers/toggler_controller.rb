class TogglerController < ApplicationController

  def index
    if session[:toggle] 
      session[:toggle] += 1
    else
      session[:toggle] = 1
    end

    render :text => "Session is now " + session[:toggle].to_s
  end
end
