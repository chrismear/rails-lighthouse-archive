require File.dirname(__FILE__) + '/../test_helper.rb'

class CommentTest < ActiveSupport::TestCase
  def test_has_a_user
    assert comments(:user_comment).user
  end
  
  def test_has_flaggings
    assert comments(:user_comment).flaggings
  end
end
