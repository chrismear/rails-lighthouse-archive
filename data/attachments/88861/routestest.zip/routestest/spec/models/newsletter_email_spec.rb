require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe NewsletterEmail do

  fixtures :newsletter_emails

  before(:each) do
    @valid_attributes = {
      :email => 'roy@80beans.com'
    }
  end

  it "should create a new instance given valid attributes" do
    NewsletterEmail.create!(@valid_attributes)
  end

  it "should not create anything with invalid attributes" do
    NewsletterEmail.create(@valid_attributes.merge!({:email => ''})).should have(2).error_on(:email)
    NewsletterEmail.create(@valid_attributes.merge!({:email => 'ron@80beans.com'})).should have(1).error_on(:email)
    NewsletterEmail.create(@valid_attributes.merge!({:email => 'grmbl@blurg'})).should have(1).error_on(:email)
  end

end
