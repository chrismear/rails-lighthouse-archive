class TestFoo < ActiveRecord::Base
end
