class ClientsController < ApplicationController

  def root; end

end
