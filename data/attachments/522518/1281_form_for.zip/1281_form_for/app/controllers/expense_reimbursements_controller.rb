class ExpenseReimbursementsController < ApplicationController
  # GET /expense_reimbursements
  # GET /expense_reimbursements.xml
  def index
    @expense_reimbursements = ExpenseReimbursement.all

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @expense_reimbursements }
    end
  end

  # GET /expense_reimbursements/1
  # GET /expense_reimbursements/1.xml
  def show
    @expense_reimbursement = ExpenseReimbursement.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @expense_reimbursement }
    end
  end

  # GET /expense_reimbursements/new
  # GET /expense_reimbursements/new.xml
  def new
    @expense_reimbursement = ExpenseReimbursement.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @expense_reimbursement }
    end
  end

  # GET /expense_reimbursements/1/edit
  def edit
    @expense_reimbursement = ExpenseReimbursement.find(params[:id])
  end

  # POST /expense_reimbursements
  # POST /expense_reimbursements.xml
  def create
    @expense_reimbursement = ExpenseReimbursement.new(params[:expense_reimbursement])

    respond_to do |format|
      if @expense_reimbursement.save
        format.html { redirect_to(@expense_reimbursement, :notice => 'Expense reimbursement was successfully created.') }
        format.xml  { render :xml => @expense_reimbursement, :status => :created, :location => @expense_reimbursement }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @expense_reimbursement.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /expense_reimbursements/1
  # PUT /expense_reimbursements/1.xml
  def update
    @expense_reimbursement = ExpenseReimbursement.find(params[:id])

    respond_to do |format|
      if @expense_reimbursement.update_attributes(params[:expense_reimbursement])
        format.html { redirect_to(@expense_reimbursement, :notice => 'Expense reimbursement was successfully updated.') }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @expense_reimbursement.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /expense_reimbursements/1
  # DELETE /expense_reimbursements/1.xml
  def destroy
    @expense_reimbursement = ExpenseReimbursement.find(params[:id])
    @expense_reimbursement.destroy

    respond_to do |format|
      format.html { redirect_to(expense_reimbursements_url) }
      format.xml  { head :ok }
    end
  end
end
