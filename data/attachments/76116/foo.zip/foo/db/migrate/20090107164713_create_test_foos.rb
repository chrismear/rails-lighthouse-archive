class CreateTestFoos < ActiveRecord::Migration
  def self.up
    create_table :test_foos do |t|

      t.timestamps
    end
  end

  def self.down
    drop_table :test_foos
  end
end
