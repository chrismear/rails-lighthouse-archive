# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
TestMigration::Application.config.secret_token = '177227b07dae111c341c31f6532943c3788ae10eee082eaf5d247de30a665e425e641e139eeb7a4399604e530c00321c875939edd088297d1b0ece97b615dc18'
