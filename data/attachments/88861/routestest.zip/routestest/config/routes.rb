ActionController::Routing::Routes.draw do |map|

  map.root :controller => 'tests'

end