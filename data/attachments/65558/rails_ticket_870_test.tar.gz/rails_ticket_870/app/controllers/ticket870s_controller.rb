class Ticket870sController < ApplicationController
  def show
  end

  def finds_the_template
    @message = "Controller action \"#{action_name}\" was called.<br />"
  end

  def finds_the_template_because_of_respond_to
    @message = render_to_string :partial => 'message'

    respond_to do |format|
      format.js
    end
  end

  def doesnt_find_the_template
    @message = render_to_string :partial => 'message'
  end
end
