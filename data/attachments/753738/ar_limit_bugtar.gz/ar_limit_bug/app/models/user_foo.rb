class UserFoo < ActiveRecord::Base
  belongs_to :user
end
