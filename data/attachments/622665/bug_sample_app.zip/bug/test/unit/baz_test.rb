require 'test_helper'

class BazTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  test "Baz.first.bar should return a Bar object when Bar has a default_scope with a select() scope" do
    assert Baz.first.bar.is_a?(Bar)
  end
end
