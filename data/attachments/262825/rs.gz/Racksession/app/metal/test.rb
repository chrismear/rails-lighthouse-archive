# Allow the metal piece to run in isolation
require(File.dirname(__FILE__) + "/../../config/environment") unless defined?(Rails)
require 'pp'

class Test
  def self.call(env)
    if env["PATH_INFO"] =~ /^\/test/
      pp(env)
      [200, {"Content-Type" => "text/html"}, ["hmmm"]]
    else
      [404, {"Content-Type" => "text/html"}, ["Not Found"]]
    end
  end
end
