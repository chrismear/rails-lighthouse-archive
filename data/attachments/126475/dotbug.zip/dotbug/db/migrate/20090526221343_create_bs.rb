class CreateBs < ActiveRecord::Migration
  def self.up
    create_table :bs do |t|
      t.string :name
      t.string :lame
      t.string :tame

      t.references :a

      t.timestamps
    end
  end

  def self.down
    drop_table :bs
  end
end
