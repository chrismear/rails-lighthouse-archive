require 'test_helper'

class EmailerTest < ActionMailer::TestCase
  # replace this with your real tests
  def test_truth
    assert true
  end


	def setup
		ActionMailer::Base.delivery_method = :test
    ActionMailer::Base.perform_deliveries = true
    ActionMailer::Base.deliveries = []
	end

	def test_general
		email = Emailer.create_general()
		assert email.parts.size > 0 #should be an html and a plain text part
	end
end
