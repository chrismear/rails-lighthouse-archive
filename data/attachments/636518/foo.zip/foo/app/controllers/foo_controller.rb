class FooController < ApplicationController
  def index
    render :text => Paper.count.to_s
  end
end
