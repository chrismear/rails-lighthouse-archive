require 'test_helper'

class ObjectBsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:object_bs)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create object_b" do
    assert_difference('ObjectB.count') do
      post :create, :object_b => { }
    end

    assert_redirected_to object_b_path(assigns(:object_b))
  end

  test "should show object_b" do
    get :show, :id => object_bs(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => object_bs(:one).to_param
    assert_response :success
  end

  test "should update object_b" do
    put :update, :id => object_bs(:one).to_param, :object_b => { }
    assert_redirected_to object_b_path(assigns(:object_b))
  end

  test "should destroy object_b" do
    assert_difference('ObjectB.count', -1) do
      delete :destroy, :id => object_bs(:one).to_param
    end

    assert_redirected_to object_bs_path
  end
end
