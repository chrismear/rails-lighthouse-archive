class ObjectD < ActiveRecord::Base
  
  has_many :object_as
	has_and_belongs_to_many :object_cs
  
end
