module ObjectAsHelper
end
