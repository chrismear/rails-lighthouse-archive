class CreatePosts < ActiveRecord::Migration
  def self.up
    execute <<-SQL
      CREATE FUNCTION uuid_generate_v1() RETURNS uuid
          LANGUAGE c STRICT
          AS '$libdir/uuid-ossp', 'uuid_generate_v1';
    
      CREATE TABLE posts (
          id character varying(36) DEFAULT uuid_generate_v1() NOT NULL,
          title character varying
      );
    SQL
  end

  def self.down
    drop_table :posts
  end
end
