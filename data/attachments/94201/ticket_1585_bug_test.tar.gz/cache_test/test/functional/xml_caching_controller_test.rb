require 'test_helper'

class XmlCachingControllerTest < ActionController::TestCase
  def setup
    ActionController::Base.perform_caching = true       #  this is meaningless - it does not overrule settings in environment/test.rb
  end

  def teardown
    ActionController::Base.perform_caching = false
  end

  def test_correct_content_type_through_proc
    # run it twice to cache it the first time
    get :index_with_cache_from_proc
    #p @response.header["Content-Type"]

    get :index_with_cache_from_proc
    #p @response.header["Content-Type"]
    
    assert_equal 'text/xml', @response.content_type     #  this assertion should fail, but it does not
  end

  def test_correct_content_type_by_string
    # run it twice to cache it the first time
    get :index_with_cache_from_string
    get :index_with_cache_from_string
    assert_equal 'text/xml', @response.content_type
  end

end



class XmlCachingControllerTest2 < ActionController::TestCase
  def setup
    ActionController::Base.perform_caching = true       #  this is meaningless - it does not overrule settings in environment/test.rb
    @controller = XmlCachingController.new
  end

  def teardown
    ActionController::Base.perform_caching = false
  end

  def test_correct_content_type_through_proc
    # run it twice to cache it the first time
    get :index_with_cache_from_proc                     #  we still get 'text/xml' here
    #p @response.header["Content-Type"]

    get :index_with_cache_from_proc                     #  and now, for the first time, 'text/html' is returned
    #p @response.header["Content-Type"]

    assert_equal 'text/xml', @response.content_type     #  fails, as we wanted to show
  end

  def test_correct_content_type_by_string
    # run it twice to cache it the first time
    get :index_with_cache_from_string
    get :index_with_cache_from_string
    assert_equal 'text/xml', @response.content_type
  end

end
