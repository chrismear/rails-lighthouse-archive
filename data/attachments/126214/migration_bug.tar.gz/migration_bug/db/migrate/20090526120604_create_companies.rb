class CreateCompanies < ActiveRecord::Migration
  def self.up
    create_table :companies do |t|
      t.string :name
      t.string :description
      t.string :type
      t.timestamps
    end
    
    Company.reset_column_information
    Company.create(:name => "Microsoft")
    Company::Firm.create(:name => "Google", :description => "search")
    Company::Firm.create(:name => "37signals", :description => "cool apps")
  end

  def self.down
    drop_table :companies
  end
end
