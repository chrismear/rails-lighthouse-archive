class User < ActiveRecord::Base
	serialize :pref, MyClass

end
