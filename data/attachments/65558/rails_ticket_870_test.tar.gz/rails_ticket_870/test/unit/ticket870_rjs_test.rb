require File.expand_path(File.dirname(__FILE__) + '/../test_helper')

class Ticket870RJSTest < ActiveSupport::TestCase
   def setup
     @controller = Ticket870sController.new
     @request    = ActionController::TestRequest.new
     @response   = ActionController::TestResponse.new
  end

  def test_action_finds_the_template
    xhr :get, :finds_the_template
    assert_response :success
  end

  def test_action_finds_the_template_because_of_respond_to
    xhr :get, :finds_the_template_because_of_respond_to
    assert_response :success
  end

  def test_action_doesnt_find_the_template
    xhr :get, :doesnt_find_the_template
    assert_response :success
  end
end
