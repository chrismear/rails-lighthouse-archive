require 'test_helper'

class UserTest < ActiveSupport::TestCase

  test "try to save a User and load it" do
		a = User.new
		a.pref = MyClass.new
		a.save!
		
		b = User.last
		
		assert b.pref.class == 'MyClass'
  end
end
