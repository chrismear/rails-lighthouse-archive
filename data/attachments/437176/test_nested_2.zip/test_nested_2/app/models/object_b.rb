class ObjectB < ActiveRecord::Base
  
  belongs_to :object_a
	has_many :object_cs

  accepts_nested_attributes_for :object_cs

end
