class User < ActiveRecord::Base
  belongs_to :account

  before_create :breakme
  
  def breakme
    if username == 'breakme'
      raise
    end
  end
end
