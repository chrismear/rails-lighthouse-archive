class MyClass
	attr_accessor :test
	
	def initialize 
		@test = 'myString'
	end
end
