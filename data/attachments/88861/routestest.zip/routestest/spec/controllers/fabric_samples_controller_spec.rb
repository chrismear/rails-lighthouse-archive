require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe FabricSamplesController do

  integrate_views

  fixtures :fabric_samples, :customer_addresses, :products, :product_variations

  before(:each) do
    @fabric_sample_attributes = {
      :first_name => 'customer',
      :last_name => 'one',
      :email => 'customer@customer.com',
      :phone => '123-4567890',
      :product_variation => product_variations(:dress_1_red)
    }
    @customer_address_attributes = {
      :address_one => 'vijzelstraat 34',
      :zip => '1017 HL',
      :country => 'NL',
      :city => 'Amsterdam'
    }
  end
  
  it "should create a fabric sample with valid input" do
    post 'create', :fabric_sample => @fabric_sample_attributes, :customer_address => @customer_address_attributes,:locale => 'nl'
    
    assigns[:fabric_sample].should be_valid
    
    response.should be_success
    response.should render_template('fabric_samples/create')
  end

  it "should not create a fabric sample with invalid input" do
    post 'create', :fabric_sample => @fabric_sample_attributes.merge(:first_name => ''), :customer_address => @customer_address_attributes,:locale => 'nl'
    
    assigns[:fabric_sample].should_not be_valid
    
    response.should be_success
    response.should render_template('fabric_samples/create')
  end

end