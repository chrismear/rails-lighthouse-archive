﻿class AddTestData < ActiveRecord::Migration
  def self.up
	Usergroup.delete_all
	Group.delete_all
	User.delete_all
	
	User.create(:name=>"Falliere",
		:lastname=>"Frédéric",
		:sex=>false,
		:email=>"frederic.falliere@gmail.com",
		:hash_pass=>"a")
	User.create(:name=>"Calvet",
		:lastname=>"Joan",
		:sex=>false,
		:email=>"frederic.falliere@gmail.com",
		:hash_pass=>"a")
	User.create(:name=>"Bermaki",
		:lastname=>"Zineb",
		:sex=>true,
		:email=>"frederic.falliere@gmail.com",
		:hash_pass=>"a")
	
	Group.create(:name=>"IGSI promo 09-10",
		:description=>"Promo IGSI de l'UT1 capitole de 2009-2010")
	
	Group.create(:name=>"TFC lovers",
		:description=>"Team fortress classic lovers ! man!")
		
	Usergroup.create(:user=>User.find_by_name("Falliere"),
		:group=>Group.find_by_name("IGSI promo 09-10"))
	Usergroup.create(:user=>User.find_by_name("Falliere"),
		:group=>Group.find_by_name("TFC lovers"))
		
	Usergroup.create(:user=>User.find_by_name("Bermaki"),
		:group=>Group.find_by_name("IGSI promo 09-10"))
		
	Usergroup.create(:user=>User.find_by_name("Calvet"),
		:group=>Group.find_by_name("TFC lovers"))
  end

  def self.down
	## supprimer uniquement les 3 utilisateurs, 2 groupes et 4 associations créés ?
	Usergroup.delete_all
	Group.delete_all
	User.delete_all
  end
end
