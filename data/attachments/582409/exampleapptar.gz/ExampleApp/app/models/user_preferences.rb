class UserPreferences

	attr_accessor :test
	
	def initialize 
		@test = Something.new
	end
end

