class Comment < ActiveRecord::Base
  belongs_to :listing
  belongs_to :user
  default_scope :order => 'created_at DESC'
end
