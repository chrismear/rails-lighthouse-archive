# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_Racksession_session',
  :secret      => 'ba059b5d2ae0e1ce051072ad7049148a348f91a5f330a3251e0e387c5dfc7afc79b9fd441d2e518005c257e821f76d83b88393c300325148e83eb150de60b249', 
  :domain     => "localhost"
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
