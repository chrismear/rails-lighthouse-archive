require 'pp'

class ActiveRecord::ConnectionAdapters::SQLite3Adapter
  def execute_with_backtrace(*args)
    begin
      raise 'backtrace'
    rescue Exception => e
      puts '-' * 80
      puts args[0]
      puts '-' * 80
      pp e.backtrace
    end
    execute_without_backtrace(*args)
  end
  alias_method_chain :execute, :backtrace
end
