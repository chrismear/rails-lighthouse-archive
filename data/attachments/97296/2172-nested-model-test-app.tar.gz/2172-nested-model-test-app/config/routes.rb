ActionController::Routing::Routes.draw do |map|
  map.resources :posts
end
