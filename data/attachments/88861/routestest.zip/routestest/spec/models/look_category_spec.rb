require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe LookCategory do
  
  fixtures :look_categories, :products, :looks

  before(:each) do
    @valid_attributes = {
      :name => 'name'
    }
  end

  it "should create a new instance given valid attributes" do
    LookCategory.create!(@valid_attributes)
  end

  it "should not create anything with invalid attributes" do
    LookCategory.create(@valid_attributes.merge!(:name => '')).should have(1).error_on(:name)
  end

end