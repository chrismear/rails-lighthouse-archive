require 'test_helper'

class ParentsHelperTest < ActionView::TestCase
end
