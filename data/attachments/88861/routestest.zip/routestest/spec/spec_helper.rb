ENV['RAILS_ENV'] = 'test'
require File.expand_path(File.dirname(__FILE__) + '/../config/environment')
require 'spec'
require 'spec/rails'

Spec::Runner.configure do |config|
  config.use_transactional_fixtures = true
  config.use_instantiated_fixtures  = false
  config.fixture_path = File.join(RAILS_ROOT, '/spec/fixtures/')
  config.before(:all) { I18n.locale = 'nl' }
  config.after(:all) { I18n.locale = 'nl' }
end

include BeansShop::ShortCut

def login(customer=:customer_one)
  controller.stub!(:current_customer).and_return(customers(customer))
end

def configure_shop
  BeansShop::Configuration.configure do |config|
    config.site_name = 'ladress'
    
    config.default_locale('nl')
    
    config.locale('nl', 'Dutch', :active => true)
    config.locale('en', 'English', :active => true)
    config.locale('fr', 'French', :active => false)
    
    config.currency('euro', :main => true)
    config.currency('usd')
    config.currency('gbp')
    
    config.tax_percentage = 19.0
    config.sha1_signature = 'beans'
    
    config.page_type(:home, :name => 'Home') do |page_type|
      page_type.content_block(:left, :name => 'Left content', :width => 200, :height => 100)
      page_type.content_block(:right, :name => 'Right content', :width => 200, :height => 100)
      page_type.image(:left, :name => 'Left image', :styles => {:custom => '130x185'})
      page_type.image(:right_1, :name => 'Right image 1', :styles => {:custom => '130x185'})
      page_type.image(:right_2, :name => 'Right image 2', :styles => {:custom => '130x185'})
    end
    config.page_type(:one_col, :name => '1 Column, 1 Picture') do |page_type|
      page_type.content_block(:left, :name => 'Left content', :width => 200, :height => 100)
      page_type.image(:right, :name => 'Right image', :styles => {:custom => '508x625'})
    end
    
    config.product_image_level = :product_variation
    config.product_image_styles = {:thumb => '70x97#', :full => '361x458#', :zoom => '700x900'}
    config.admin_product_image_style = :thumb
    
    config.property_group(:fabric, 'Fabric', :editable => true, :level => :product, :single => true) do |fabric|
      fabric.combination(:color, :image => true, :image_styles => {:thumb => '32x32#', :bigger_thumb => '38x38#', :full => '70x70#'})
    end
    config.property_group(:color, 'Color', :editable => true, :level => :product_variation, :single => true,
                                            :image => true, :image_styles => {:thumb => '32x32#', :full => '70x70#'})
    config.property_group(:size, 'Size', :editable => true, :level => :product_unit, :single => true) do |size|
      size.combination(:color)
    end
  end
end

def remove_uploads
  FileUtils.rm_rf(File.join(RAILS_ROOT, '/tmp/uploads'))
end

def get_test_file(file='shadow.png', sub_path='', mimetype='image/png')
  ActionController::TestUploadedFile.new(File.join(File.dirname(__FILE__), 'fixtures', 'images', sub_path, file), mimetype)
end

def locale
  I18n.locale
end