require 'test_helper'

class ThingsHelperTest < ActionView::TestCase
end
