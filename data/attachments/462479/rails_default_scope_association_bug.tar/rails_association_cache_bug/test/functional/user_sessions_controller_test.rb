require File.dirname(__FILE__) + '/../test_helper.rb'

class UserSessionsControllerTest < ActionController::TestCase
  setup :activate_authlogic
  
  def test_should_view_login_page
    get :new
    assert_response :success
    assert assigns(:user_session)
  end
  
  def test_should_logout_with_user
    user = users(:user)
    UserSession.create(user)
    assert_equal controller.session["user_credentials"], user.persistence_token
    delete :destroy
    assert flash[:notice]
    assert_redirected_to root_path
    assert_nil controller.session["user_credentials"]
  end
  
  def test_should_redirect_without_user
    assert_nil controller.session["user_credentials"]
    delete :destroy
    assert_nil flash[:notice]
    assert_redirected_to root_path
    assert_nil controller.session["user_credentials"]
  end
end
