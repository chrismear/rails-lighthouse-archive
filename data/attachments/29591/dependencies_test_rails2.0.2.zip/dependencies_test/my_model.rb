class MyModel < ActiveRecord::Base

end