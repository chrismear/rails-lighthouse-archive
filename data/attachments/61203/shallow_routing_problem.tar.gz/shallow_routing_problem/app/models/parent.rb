class Parent < ActiveRecord::Base
end
