require 'test_helper'

class ImposterHelperTest < ActionView::TestCase
end
