class HouseholdPerson < ActiveRecord::Base
  belongs_to :household
  belongs_to :person
end
