class PostSweeper < ActionController::Caching::Sweeper
  observe Post

  def after_save(resource)
    expire_cache(resource)
  end

  def after_destroy(resource)
    expire_cache(resource)
  end

private
  def expire_cache(resource)
    expire_page :controller => "posts", :action => "index"
  end
end