# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Myapp::Application.config.secret_token = 'c3b9a66dd43993236fae2a0ee927159b9628639a5f6244decbb6f80270a0e84c69eaf1a936f6925d8157d4a8813835987bfd53c7880555a92910a04d335a5a69'
