class Bone < ActiveRecord::Base
end
