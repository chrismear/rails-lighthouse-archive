class UsersController < ApplicationController

  def index
    # creating a Monkey to wreak havoc
    @m = Monkey.new
    @users = User.find(:all)
  end

end
