class A < ActiveRecord::Base
  belongs_to :c
  has_many :bs
end
