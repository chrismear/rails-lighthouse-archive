require File.expand_path(File.dirname(__FILE__) + '/../../spec_helper')

describe Admin::FabricSamplesController do

  integrate_views

  fixtures :products, :product_variations, :fabric_samples, :customer_addresses

  it "should get index" do
    get 'index'
    
    assigns[:fabric_samples].should_not be_nil
    assigns[:fabric_samples].should have(2).items
    assigns[:sent_fabric_samples].should_not be_nil
    assigns[:sent_fabric_samples].should have(0).items
    
    response.should be_success
    response.should render_template('admin/fabric_samples/index')
  end

  it "should show show" do
    get 'show', :id => fabric_samples(:sample_one)
    
    assigns[:fabric_sample].should_not be_nil
    
    response.should be_success
    response.should render_template('admin/fabric_samples/show')
  end

  it "should update a fabric sample" do
    post 'update', :id => fabric_samples(:sample_one)
    
    assigns[:fabric_sample].should_not be_nil
    assigns[:fabric_sample].sent.should be_true
    
    response.should be_success
    response.should render_template('admin/fabric_samples/update')
  end

end