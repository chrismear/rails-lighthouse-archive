class Bar < ActiveRecord::Base
  
  has_many :linkages, :as => :thing

   
end