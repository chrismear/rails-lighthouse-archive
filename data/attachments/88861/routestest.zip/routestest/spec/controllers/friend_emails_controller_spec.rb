require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe FriendEmailsController do

  fixtures :categories, :products

  it "should send an email to a friend" do
    lambda {
      post 'create', :locale => 'nl', :category_id => categories(:dresses), :product_id => products(:dress_4_empty), :name => 'simone', :email => 'simone@ladress.com', :friend_name => 'ans', :friend_email => 'ans@ladress.com', :text => 'kijk eens wat mooi'
    }.should change(ActionMailer::Base.deliveries, :length).by(1)
  
    response.should be_success
    response.should render_template('friend_emails/create')
  end

  it "should not send an email to a friend without emails" do
    lambda {
      post 'create', :locale => 'nl', :category_id => categories(:dresses), :product_id => products(:dress_4_empty), :name => 'simone', :email => '', :friend_name => 'ans', :friend_email => '', :text => 'kijk eens wat mooi'
    }.should change(ActionMailer::Base.deliveries, :length).by(0)
  
    response.should be_success
    response.should render_template('friend_emails/create')
  end

end