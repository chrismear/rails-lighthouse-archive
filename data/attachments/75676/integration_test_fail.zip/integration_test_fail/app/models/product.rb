class Product < ActiveRecord::Base
end
