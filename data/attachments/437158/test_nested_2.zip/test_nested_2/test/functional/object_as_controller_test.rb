require 'test_helper'

class ObjectAsControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:object_as)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create object_a" do
    assert_difference('ObjectA.count') do
      post :create, :object_a => { }
    end

    assert_redirected_to object_a_path(assigns(:object_a))
  end

  test "should show object_a" do
    get :show, :id => object_as(:one).to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => object_as(:one).to_param
    assert_response :success
  end

  test "should update object_a" do
    put :update, :id => object_as(:one).to_param, :object_a => { }
    assert_redirected_to object_a_path(assigns(:object_a))
  end

  test "should destroy object_a" do
    assert_difference('ObjectA.count', -1) do
      delete :destroy, :id => object_as(:one).to_param
    end

    assert_redirected_to object_as_path
  end
end
