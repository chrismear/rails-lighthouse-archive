# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_TestNested_session',
  :secret      => '7bade313a76c7681fbc85fc8e6e0d7848f22f257a8cf78e70b2193047e5c23527d286c0b36ba0c5c7e1897a277ab823bad9603452947f4e4f894562b5d329e51'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
