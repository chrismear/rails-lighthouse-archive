ActiveSupport::Inflector.inflections do |inflect|
  inflect.irregular 'test', 'tests'
end